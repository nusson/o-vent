# WordPress MySQL database migration
#
# Generated: Saturday 14. October 2017 17:56 UTC
# Hostname: localhost
# Database: `o-vent`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un commentateur WordPress', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2017-03-05 00:17:02', '2017-03-04 23:17:02', 'Bonjour, ceci est un commentaire.\\n\nPour débuter avec la modération, la modification et la suppression de commentaires, veuillez visiter l’écran des Commentaires dans le Tableau de bord.\\n\nLes avatars des personnes qui commentent arrivent depuis <a href="https://gravatar.com">Gravatar</a>.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=988 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://ovent.busbz.com', 'yes'),
(2, 'home', 'http://ovent.busbz.com', 'yes'),
(3, 'blogname', 'O-vent', 'yes'),
(4, 'blogdescription', 'Un site utilisant WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'hello@nusson.ninja', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G \\h i \\m\\i\\n', 'yes'),
(25, 'links_updated_date_format', 'j F Y G \\h i \\m\\i\\n', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:10:{i:0;s:21:"polylang/polylang.php";i:1;s:68:"acf-fields-repeater-collapser-admin/acf-repeater-collapser-admin.php";i:2;s:56:"acf-repeater-editor-accordion/acf-repeater-accordion.php";i:3;s:34:"advanced-custom-fields-pro/acf.php";i:4;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:5;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:6;s:61:"theme-translation-for-polylang/polylang-theme-translation.php";i:7;s:25:"timber-library/timber.php";i:8;s:31:"wp-migrate-db/wp-migrate-db.php";i:9;s:37:"wp-mobile-detect/wp-mobile-detect.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '1', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:3:{i:0;s:94:"C:\\stock\\www\\ovent\\httpdocs/wp-content/plugins/regenerate-thumbnails/regenerate-thumbnails.php";i:1;s:81:"C:\\stock\\www\\ovent\\httpdocs/wp-content/plugins/advanced-custom-fields-pro/acf.php";i:2;s:0:"";}', 'no'),
(40, 'template', 'ovent', 'yes'),
(41, 'stylesheet', 'ovent', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '1024', 'yes'),
(62, 'medium_size_h', '0', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1600', 'yes'),
(65, 'large_size_h', '0', 'yes'),
(66, 'image_default_link_type', '', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '56', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '38590', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'fresh_site', '0', 'yes'),
(94, 'WPLANG', 'fr_CA', 'yes'),
(95, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(101, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'cron', 'a:4:{i:1508023022;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1508023110;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1508087965;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'theme_mods_twentyseventeen', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1488669515;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(123, 'can_compress_scripts', '1', 'no'),
(136, 'current_theme', 'Ovent', 'yes'),
(137, 'theme_mods_ovent', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:5;}}', 'yes'),
(138, 'theme_switched', '', 'yes'),
(139, 'recently_activated', 'a:0:{}', 'yes'),
(146, 'polylang', 'a:15:{s:7:"browser";i:1;s:7:"rewrite";i:1;s:12:"hide_default";i:0;s:10:"force_lang";i:1;s:13:"redirect_lang";i:1;s:13:"media_support";b:0;s:9:"uninstall";i:0;s:4:"sync";a:0:{}s:10:"post_types";a:0:{}s:10:"taxonomies";a:0:{}s:7:"domains";a:0:{}s:7:"version";s:5:"2.1.5";s:12:"default_lang";s:2:"fr";s:9:"nav_menus";a:1:{s:5:"ovent";a:1:{s:7:"primary";a:2:{s:2:"fr";i:5;s:2:"en";i:12;}}}s:16:"previous_version";s:5:"2.1.2";}', 'yes'),
(147, 'polylang_wpml_strings', 'a:0:{}', 'yes'),
(148, 'widget_polylang', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(152, 'theme_mods_twentyfifteen', 'a:3:{i:0;b:0;s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1488671236;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(169, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(195, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:18:"hello@nusson.ninja";s:7:"version";s:5:"4.8.2";s:9:"timestamp";i:1507997245;}', 'no'),
(236, 'category_children', 'a:0:{}', 'yes'),
(312, 'cptui_new_install', 'false', 'yes'),
(313, 'acf_version', '5.5.10', 'yes'),
(316, 'cptui_post_types', 'a:1:{s:4:"shop";a:28:{s:4:"name";s:4:"shop";s:5:"label";s:9:"Boutiques";s:14:"singular_label";s:8:"Boutique";s:11:"description";s:0:"";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:12:"show_in_rest";s:5:"false";s:9:"rest_base";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";s:14:"dashicons-cart";s:8:"supports";a:1:{i:0;s:5:"title";}s:10:"taxonomies";a:0:{}s:6:"labels";a:23:{s:9:"all_items";s:20:"Toutes les boutiques";s:7:"add_new";s:20:"Ajouter une boutique";s:12:"add_new_item";s:20:"Ajouter une boutique";s:9:"edit_item";s:20:"Modifier la boutique";s:8:"new_item";s:17:"Nouvelle boutique";s:9:"menu_name";s:0:"";s:9:"view_item";s:0:"";s:10:"view_items";s:0:"";s:12:"search_items";s:0:"";s:9:"not_found";s:0:"";s:18:"not_found_in_trash";s:0:"";s:17:"parent_item_colon";s:0:"";s:14:"featured_image";s:0:"";s:18:"set_featured_image";s:0:"";s:21:"remove_featured_image";s:0:"";s:18:"use_featured_image";s:0:"";s:8:"archives";s:0:"";s:16:"insert_into_item";s:0:"";s:21:"uploaded_to_this_item";s:0:"";s:17:"filter_items_list";s:0:"";s:21:"items_list_navigation";s:0:"";s:10:"items_list";s:0:"";s:10:"attributes";s:0:"";}s:15:"custom_supports";s:0:"";}}', 'yes'),
(325, 'cptui_taxonomies', 'a:0:{}', 'yes'),
(413, 'rewrite_rules', 'a:169:{s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:55:"(fr|en)/category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:50:"(fr|en)/category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:69:"index.php?lang=$matches[1]&category_name=$matches[2]&feed=$matches[3]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:31:"(fr|en)/category/(.+?)/embed/?$";s:63:"index.php?lang=$matches[1]&category_name=$matches[2]&embed=true";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:43:"(fr|en)/category/(.+?)/page/?([0-9]{1,})/?$";s:70:"index.php?lang=$matches[1]&category_name=$matches[2]&paged=$matches[3]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:25:"(fr|en)/category/(.+?)/?$";s:52:"index.php?lang=$matches[1]&category_name=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:52:"(fr|en)/tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:47:"(fr|en)/tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&tag=$matches[2]&feed=$matches[3]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:28:"(fr|en)/tag/([^/]+)/embed/?$";s:53:"index.php?lang=$matches[1]&tag=$matches[2]&embed=true";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:40:"(fr|en)/tag/([^/]+)/page/?([0-9]{1,})/?$";s:60:"index.php?lang=$matches[1]&tag=$matches[2]&paged=$matches[3]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:22:"(fr|en)/tag/([^/]+)/?$";s:42:"index.php?lang=$matches[1]&tag=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:53:"(fr|en)/type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]";s:48:"(fr|en)/type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&post_format=$matches[2]&feed=$matches[3]";s:29:"(fr|en)/type/([^/]+)/embed/?$";s:61:"index.php?lang=$matches[1]&post_format=$matches[2]&embed=true";s:41:"(fr|en)/type/([^/]+)/page/?([0-9]{1,})/?$";s:68:"index.php?lang=$matches[1]&post_format=$matches[2]&paged=$matches[3]";s:23:"(fr|en)/type/([^/]+)/?$";s:50:"index.php?lang=$matches[1]&post_format=$matches[2]";s:32:"shop/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:42:"shop/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:62:"shop/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"shop/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:57:"shop/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:38:"shop/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:21:"shop/([^/]+)/embed/?$";s:37:"index.php?shop=$matches[1]&embed=true";s:25:"shop/([^/]+)/trackback/?$";s:31:"index.php?shop=$matches[1]&tb=1";s:33:"shop/([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?shop=$matches[1]&paged=$matches[2]";s:40:"shop/([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?shop=$matches[1]&cpage=$matches[2]";s:29:"shop/([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?shop=$matches[1]&page=$matches[2]";s:21:"shop/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:31:"shop/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:51:"shop/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"shop/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:46:"shop/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:27:"shop/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:40:"(fr|en)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?lang=$matches[1]&&feed=$matches[2]";s:35:"(fr|en)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?lang=$matches[1]&&feed=$matches[2]";s:16:"(fr|en)/embed/?$";s:38:"index.php?lang=$matches[1]&&embed=true";s:28:"(fr|en)/page/?([0-9]{1,})/?$";s:45:"index.php?lang=$matches[1]&&paged=$matches[2]";s:35:"(fr|en)/comment-page-([0-9]{1,})/?$";s:56:"index.php?lang=$matches[1]&&page_id=56&cpage=$matches[2]";s:10:"(fr|en)/?$";s:26:"index.php?lang=$matches[1]";s:49:"(fr|en)/comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1";s:44:"(fr|en)/comments/(feed|rdf|rss|rss2|atom)/?$";s:59:"index.php?lang=$matches[1]&&feed=$matches[2]&withcomments=1";s:25:"(fr|en)/comments/embed/?$";s:38:"index.php?lang=$matches[1]&&embed=true";s:52:"(fr|en)/search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]";s:47:"(fr|en)/search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:57:"index.php?lang=$matches[1]&s=$matches[2]&feed=$matches[3]";s:28:"(fr|en)/search/(.+)/embed/?$";s:51:"index.php?lang=$matches[1]&s=$matches[2]&embed=true";s:40:"(fr|en)/search/(.+)/page/?([0-9]{1,})/?$";s:58:"index.php?lang=$matches[1]&s=$matches[2]&paged=$matches[3]";s:22:"(fr|en)/search/(.+)/?$";s:40:"index.php?lang=$matches[1]&s=$matches[2]";s:55:"(fr|en)/author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]";s:50:"(fr|en)/author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:67:"index.php?lang=$matches[1]&author_name=$matches[2]&feed=$matches[3]";s:31:"(fr|en)/author/([^/]+)/embed/?$";s:61:"index.php?lang=$matches[1]&author_name=$matches[2]&embed=true";s:43:"(fr|en)/author/([^/]+)/page/?([0-9]{1,})/?$";s:68:"index.php?lang=$matches[1]&author_name=$matches[2]&paged=$matches[3]";s:25:"(fr|en)/author/([^/]+)/?$";s:50:"index.php?lang=$matches[1]&author_name=$matches[2]";s:77:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]";s:72:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&feed=$matches[5]";s:53:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:91:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&embed=true";s:65:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:98:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&paged=$matches[5]";s:47:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:80:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]";s:64:"(fr|en)/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]";s:59:"(fr|en)/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&feed=$matches[4]";s:40:"(fr|en)/([0-9]{4})/([0-9]{1,2})/embed/?$";s:75:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&embed=true";s:52:"(fr|en)/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:82:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&paged=$matches[4]";s:34:"(fr|en)/([0-9]{4})/([0-9]{1,2})/?$";s:64:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]";s:51:"(fr|en)/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]";s:46:"(fr|en)/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:60:"index.php?lang=$matches[1]&year=$matches[2]&feed=$matches[3]";s:27:"(fr|en)/([0-9]{4})/embed/?$";s:54:"index.php?lang=$matches[1]&year=$matches[2]&embed=true";s:39:"(fr|en)/([0-9]{4})/page/?([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&year=$matches[2]&paged=$matches[3]";s:21:"(fr|en)/([0-9]{4})/?$";s:43:"index.php?lang=$matches[1]&year=$matches[2]";s:66:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:76:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:96:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:91:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:91:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:72:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:61:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:108:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:65:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:102:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&tb=1";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:85:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:114:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&feed=$matches[6]";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:80:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:114:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&feed=$matches[6]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:73:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:115:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&paged=$matches[6]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:80:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:115:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&cpage=$matches[6]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:69:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:114:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&name=$matches[5]&page=$matches[6]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:55:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:65:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:85:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:80:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:80:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:61:"(fr|en)/[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:72:"(fr|en)/([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:98:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&day=$matches[4]&cpage=$matches[5]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:59:"(fr|en)/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:82:"index.php?lang=$matches[1]&year=$matches[2]&monthnum=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:46:"(fr|en)/([0-9]{4})/comment-page-([0-9]{1,})/?$";s:61:"index.php?lang=$matches[1]&year=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:35:"(fr|en)/.?.+?/attachment/([^/]+)/?$";s:49:"index.php?lang=$matches[1]&attachment=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"(fr|en)/.?.+?/attachment/([^/]+)/trackback/?$";s:54:"index.php?lang=$matches[1]&attachment=$matches[2]&tb=1";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"(fr|en)/.?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"(fr|en)/.?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:66:"index.php?lang=$matches[1]&attachment=$matches[2]&feed=$matches[3]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"(fr|en)/.?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:67:"index.php?lang=$matches[1]&attachment=$matches[2]&cpage=$matches[3]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"(fr|en)/.?.+?/attachment/([^/]+)/embed/?$";s:60:"index.php?lang=$matches[1]&attachment=$matches[2]&embed=true";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"(fr|en)/(.?.+?)/embed/?$";s:58:"index.php?lang=$matches[1]&pagename=$matches[2]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:28:"(fr|en)/(.?.+?)/trackback/?$";s:52:"index.php?lang=$matches[1]&pagename=$matches[2]&tb=1";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:48:"(fr|en)/(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:43:"(fr|en)/(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&feed=$matches[3]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:36:"(fr|en)/(.?.+?)/page/?([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&pagename=$matches[2]&paged=$matches[3]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:43:"(fr|en)/(.?.+?)/comment-page-([0-9]{1,})/?$";s:65:"index.php?lang=$matches[1]&pagename=$matches[2]&cpage=$matches[3]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:32:"(fr|en)/(.?.+?)(?:/([0-9]+))?/?$";s:64:"index.php?lang=$matches[1]&pagename=$matches[2]&page=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(462, 'options_credits_0_link', 'http://www.dyadephoto.com/', 'no'),
(463, '_options_credits_0_link', 'field_58d0a8e1ad07f', 'no'),
(464, 'options_credits_0_label', 'Crédits photo: Dyade photo', 'no'),
(465, '_options_credits_0_label', 'field_58d0a952ad081', 'no'),
(466, 'options_credits_0_image', '100', 'no'),
(467, '_options_credits_0_image', 'field_58d0a92bad080', 'no'),
(468, 'options_credits', '2', 'no'),
(469, '_options_credits', 'field_58d0a8bdad07e', 'no'),
(470, 'options_credits_1_link', 'https://signelocal.com/entreprises/o-vent/', 'no'),
(471, '_options_credits_1_link', 'field_58d0a8e1ad07f', 'no'),
(472, 'options_credits_1_label', 'Signé local', 'no'),
(473, '_options_credits_1_label', 'field_58d0a952ad081', 'no'),
(474, 'options_credits_1_image', '99', 'no'),
(475, '_options_credits_1_image', 'field_58d0a92bad080', 'no'),
(879, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(880, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(881, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(961, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=776 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_pll_strings_translations', 'a:0:{}'),
(21, 7, '_pll_strings_translations', 'a:0:{}'),
(22, 8, '_edit_last', '1'),
(23, 8, '_edit_lock', '1495672140:1'),
(24, 10, '_edit_last', '1'),
(25, 10, '_edit_lock', '1495671734:1'),
(26, 15, '_menu_item_type', 'post_type'),
(27, 15, '_menu_item_menu_item_parent', '0'),
(28, 15, '_menu_item_object_id', '8'),
(29, 15, '_menu_item_object', 'page'),
(30, 15, '_menu_item_target', ''),
(31, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(32, 15, '_menu_item_xfn', ''),
(33, 15, '_menu_item_url', ''),
(35, 16, '_menu_item_type', 'custom'),
(36, 16, '_menu_item_menu_item_parent', '0'),
(37, 16, '_menu_item_object_id', '16'),
(38, 16, '_menu_item_object', 'custom'),
(39, 16, '_menu_item_target', ''),
(40, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(41, 16, '_menu_item_xfn', ''),
(42, 16, '_menu_item_url', '#pll_switcher'),
(44, 16, '_pll_menu_item', 'a:6:{s:22:"hide_if_no_translation";i:0;s:12:"hide_current";i:1;s:10:"force_home";i:0;s:10:"show_flags";i:0;s:10:"show_names";i:1;s:8:"dropdown";i:0;}'),
(45, 18, '_edit_last', '1'),
(46, 18, '_edit_lock', '1495670880:1'),
(47, 19, '_edit_last', '1'),
(48, 19, '_edit_lock', '1489987756:1'),
(49, 22, '_menu_item_type', 'post_type'),
(50, 22, '_menu_item_menu_item_parent', '0'),
(51, 22, '_menu_item_object_id', '18'),
(52, 22, '_menu_item_object', 'page'),
(53, 22, '_menu_item_target', ''),
(54, 22, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(55, 22, '_menu_item_xfn', ''),
(56, 22, '_menu_item_url', ''),
(58, 23, '_menu_item_type', 'custom'),
(59, 23, '_menu_item_menu_item_parent', '0'),
(60, 23, '_menu_item_object_id', '23'),
(61, 23, '_menu_item_object', 'custom'),
(62, 23, '_menu_item_target', '_blank'),
(63, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(64, 23, '_menu_item_xfn', ''),
(65, 23, '_menu_item_url', 'https://www.etsy.com/fr/shop/OventEcoCreation'),
(67, 24, '_menu_item_type', 'custom'),
(68, 24, '_menu_item_menu_item_parent', '0'),
(69, 24, '_menu_item_object_id', '24'),
(70, 24, '_menu_item_object', 'custom'),
(71, 24, '_menu_item_target', ''),
(72, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(73, 24, '_menu_item_xfn', ''),
(74, 24, '_menu_item_url', '#pll_switcher'),
(76, 25, '_menu_item_type', 'post_type'),
(77, 25, '_menu_item_menu_item_parent', '0'),
(78, 25, '_menu_item_object_id', '19'),
(79, 25, '_menu_item_object', 'page'),
(80, 25, '_menu_item_target', ''),
(81, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 25, '_menu_item_xfn', ''),
(83, 25, '_menu_item_url', ''),
(94, 27, '_menu_item_type', 'custom'),
(95, 27, '_menu_item_menu_item_parent', '0'),
(96, 27, '_menu_item_object_id', '27'),
(97, 27, '_menu_item_object', 'custom'),
(98, 27, '_menu_item_target', ''),
(99, 27, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(100, 27, '_menu_item_xfn', ''),
(101, 27, '_menu_item_url', 'https://www.etsy.com/ca/shop/OventEcoCreation'),
(103, 24, '_pll_menu_item', 'a:6:{s:22:"hide_if_no_translation";i:0;s:12:"hide_current";i:1;s:10:"force_home";i:0;s:10:"show_flags";i:0;s:10:"show_names";i:1;s:8:"dropdown";i:0;}'),
(104, 31, '_edit_last', '1'),
(105, 31, '_edit_lock', '1489869736:1'),
(106, 32, '_edit_last', '1'),
(107, 32, '_edit_lock', '1489957802:1'),
(108, 31, '_wp_old_slug', 'ccc'),
(109, 31, 'address', '290, rue de la Montagne'),
(110, 31, '_address', 'field_58cd962fa0b1b'),
(111, 31, 'address_bis', 'Montréal'),
(112, 31, '_address_bis', 'field_58cd966fa0b1c'),
(113, 31, 'map', 'a:3:{s:7:"address";s:44:"290 Rue de la Montagne, Montreal, QC, Canada";s:3:"lat";s:17:"45.49196999999999";s:3:"lng";s:10:"-73.561802";}'),
(114, 31, '_map', 'field_58cd96e4a0b20'),
(115, 31, 'web', 'http://www.le5ieme.com'),
(116, 31, '_web', 'field_58cd9685a0b1d'),
(117, 31, 'email', ''),
(118, 31, '_email', 'field_58cd96b3a0b1e'),
(119, 31, 'phone', ''),
(120, 31, '_phone', 'field_58cd96c6a0b1f'),
(121, 41, '_edit_last', '1'),
(122, 41, '_edit_lock', '1495670933:1'),
(123, 41, 'address', 'Mile-End'),
(124, 41, '_address', 'field_58cd962fa0b1b'),
(125, 41, 'address_bis', 'Montréal'),
(126, 41, '_address_bis', 'field_58cd966fa0b1c'),
(127, 41, 'map', 'a:3:{s:7:"address";s:38:"5231 Park Avenue, Montreal, QC, Canada";s:3:"lat";s:10:"45.5207876";s:3:"lng";s:11:"-73.5983531";}'),
(128, 41, '_map', 'field_58cd96e4a0b20'),
(129, 41, 'web', ''),
(130, 41, '_web', 'field_58cd9685a0b1d'),
(131, 41, 'email', ''),
(132, 41, '_email', 'field_58cd96b3a0b1e'),
(133, 41, 'phone', '(514) 686-2486'),
(134, 41, '_phone', 'field_58cd96c6a0b1f'),
(135, 42, '_edit_last', '1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(136, 42, '_edit_lock', '1489957802:1'),
(137, 42, 'address', '4019, rue Notre-Dame O.'),
(138, 42, '_address', 'field_58cd962fa0b1b'),
(139, 42, 'address_bis', '(St-Henri) Montréal'),
(140, 42, '_address_bis', 'field_58cd966fa0b1c'),
(141, 42, 'map', 'a:3:{s:7:"address";s:47:"4019 Rue Notre-Dame Ouest, Montreal, QC, Canada";s:3:"lat";s:10:"45.4777351";s:3:"lng";s:18:"-73.58464620000001";}'),
(142, 42, '_map', 'field_58cd96e4a0b20'),
(143, 42, 'web', 'http://www.lagaillarde.ca'),
(144, 42, '_web', 'field_58cd9685a0b1d'),
(145, 42, 'email', ''),
(146, 42, '_email', 'field_58cd96b3a0b1e'),
(147, 42, 'phone', '(514) 989-5134'),
(148, 42, '_phone', 'field_58cd96c6a0b1f'),
(149, 18, '_wp_page_template', 'template-shops.php'),
(150, 44, '_edit_last', '1'),
(151, 44, '_edit_lock', '1489871838:1'),
(152, 18, 'shops', 'a:3:{i:0;s:2:"41";i:1;s:2:"42";i:2;s:2:"31";}'),
(153, 18, '_shops', 'field_58cda3ad9afe3'),
(154, 46, 'shops', ''),
(155, 46, '_shops', 'field_58cda3ad9afe3'),
(156, 47, 'shops', 'a:3:{i:0;s:2:"41";i:1;s:2:"42";i:2;s:2:"31";}'),
(157, 47, '_shops', 'field_58cda3ad9afe3'),
(158, 48, '_wp_attached_file', '2017/03/photo-site-o-vent-bio1.png'),
(159, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:671;s:6:"height";i:447;s:4:"file";s:34:"2017/03/photo-site-o-vent-bio1.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:34:"photo-site-o-vent-bio1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:5:"small";a:4:{s:4:"file";s:34:"photo-site-o-vent-bio1-640x426.png";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(161, 8, '_wp_page_template', 'default'),
(162, 52, '_menu_item_type', 'post_type'),
(163, 52, '_menu_item_menu_item_parent', '0'),
(164, 52, '_menu_item_object_id', '10'),
(165, 52, '_menu_item_object', 'page'),
(166, 52, '_menu_item_target', ''),
(167, 52, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(168, 52, '_menu_item_xfn', ''),
(169, 52, '_menu_item_url', ''),
(171, 10, '_thumbnail_id', '48'),
(172, 10, '_wp_page_template', 'default'),
(173, 19, '_wp_page_template', 'template-shops.php'),
(174, 19, 'shops', 'a:3:{i:0;s:2:"41";i:1;s:2:"42";i:2;s:2:"31";}'),
(175, 19, '_shops', 'field_58cda3ad9afe3'),
(176, 53, 'shops', ''),
(177, 53, '_shops', 'field_58cda3ad9afe3'),
(178, 54, 'shops', 'a:3:{i:0;s:2:"41";i:1;s:2:"42";i:2;s:2:"31";}'),
(179, 54, '_shops', 'field_58cda3ad9afe3'),
(182, 56, '_wp_page_template', 'template-home.php'),
(183, 56, '_edit_last', '1'),
(184, 56, '_edit_lock', '1499282029:1'),
(185, 60, '_menu_item_type', 'post_type'),
(186, 60, '_menu_item_menu_item_parent', '0'),
(187, 60, '_menu_item_object_id', '56'),
(188, 60, '_menu_item_object', 'page'),
(189, 60, '_menu_item_target', ''),
(190, 60, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(191, 60, '_menu_item_xfn', ''),
(192, 60, '_menu_item_url', ''),
(203, 63, '_edit_last', '1'),
(204, 63, '_edit_lock', '1499285999:1'),
(217, 69, '_wp_attached_file', '2017/03/o-vent-pret-a-porter.png'),
(218, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:658;s:6:"height";i:438;s:4:"file";s:32:"2017/03/o-vent-pret-a-porter.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:32:"o-vent-pret-a-porter-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:5:"small";a:4:{s:4:"file";s:32:"o-vent-pret-a-porter-640x426.png";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(219, 70, '_wp_attached_file', '2017/03/o-vent-reparation.png'),
(220, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:645;s:6:"height";i:431;s:4:"file";s:29:"2017/03/o-vent-reparation.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"o-vent-reparation-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:5:"small";a:4:{s:4:"file";s:29:"o-vent-reparation-640x428.png";s:5:"width";i:640;s:6:"height";i:428;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(221, 71, '_wp_attached_file', '2017/03/o-vent-sur-mesure.png'),
(222, 71, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:692;s:6:"height";i:453;s:4:"file";s:29:"2017/03/o-vent-sur-mesure.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"o-vent-sur-mesure-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:5:"small";a:4:{s:4:"file";s:29:"o-vent-sur-mesure-640x419.png";s:5:"width";i:640;s:6:"height";i:419;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(419, 87, '_wp_page_template', 'template-home.php'),
(420, 87, '_edit_last', '1'),
(421, 87, '_edit_lock', '1499290289:1'),
(422, 87, 'items_0_title', 'Les bobettes'),
(423, 87, '_items_0_title', 'field_58d064d3c471b'),
(424, 87, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(425, 87, '_items_0_content', 'field_58d05f574d4a5'),
(426, 87, 'items_0_images', 'a:11:{i:0;s:3:"128";i:1;s:3:"127";i:2;s:3:"126";i:3;s:3:"125";i:4;s:3:"124";i:5;s:3:"123";i:6;s:3:"121";i:7;s:3:"120";i:8;s:3:"119";i:9;s:3:"118";i:10;s:3:"117";}'),
(427, 87, '_items_0_images', 'field_58d0642e9bdea'),
(428, 87, 'items_1_title', 'La collection zéro déchet'),
(429, 87, '_items_1_title', 'field_58d064d3c471b'),
(430, 87, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(431, 87, '_items_1_content', 'field_58d05f574d4a5'),
(432, 87, 'items_1_images', 'a:8:{i:0;s:3:"136";i:1;s:3:"135";i:2;s:3:"134";i:3;s:3:"133";i:4;s:3:"132";i:5;s:3:"131";i:6;s:3:"130";i:7;s:3:"129";}'),
(433, 87, '_items_1_images', 'field_58d0642e9bdea'),
(434, 87, 'items', '2'),
(435, 87, '_items', 'field_58d05f0bbfde7'),
(436, 87, 'delay', '8'),
(437, 87, '_delay', 'field_58d0624d7eb15'),
(438, 88, 'items_0_title', 'Les bobettes'),
(439, 88, '_items_0_title', 'field_58d064d3c471b'),
(440, 88, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(441, 88, '_items_0_content', 'field_58d05f574d4a5'),
(442, 88, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(443, 88, '_items_0_images', 'field_58d0642e9bdea'),
(444, 88, 'items_1_title', 'La collection zéro déchet'),
(445, 88, '_items_1_title', 'field_58d064d3c471b'),
(446, 88, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(447, 88, '_items_1_content', 'field_58d05f574d4a5'),
(448, 88, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(449, 88, '_items_1_images', 'field_58d0642e9bdea'),
(450, 88, 'items', '2'),
(451, 88, '_items', 'field_58d05f0bbfde7'),
(452, 88, 'delay', '8'),
(453, 88, '_delay', 'field_58d0624d7eb15'),
(454, 89, '_menu_item_type', 'post_type'),
(455, 89, '_menu_item_menu_item_parent', '0'),
(456, 89, '_menu_item_object_id', '87'),
(457, 89, '_menu_item_object', 'page') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(458, 89, '_menu_item_target', ''),
(459, 89, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(460, 89, '_menu_item_xfn', ''),
(461, 89, '_menu_item_url', ''),
(464, 91, 'items_0_title', 'Les bobettes'),
(465, 91, '_items_0_title', 'field_58d064d3c471b'),
(466, 91, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(467, 91, '_items_0_content', 'field_58d05f574d4a5'),
(468, 91, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(469, 91, '_items_0_images', 'field_58d0642e9bdea'),
(470, 91, 'items_1_title', 'La collection zéro déchet'),
(471, 91, '_items_1_title', 'field_58d064d3c471b'),
(472, 91, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(473, 91, '_items_1_content', 'field_58d05f574d4a5'),
(474, 91, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(475, 91, '_items_1_images', 'field_58d0642e9bdea'),
(476, 91, 'items', '2'),
(477, 91, '_items', 'field_58d05f0bbfde7'),
(478, 91, 'delay', '8'),
(479, 91, '_delay', 'field_58d0624d7eb15'),
(480, 92, 'items_0_title', 'Les bobettes'),
(481, 92, '_items_0_title', 'field_58d064d3c471b'),
(482, 92, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(483, 92, '_items_0_content', 'field_58d05f574d4a5'),
(484, 92, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(485, 92, '_items_0_images', 'field_58d0642e9bdea'),
(486, 92, 'items_1_title', 'La collection zéro déchet'),
(487, 92, '_items_1_title', 'field_58d064d3c471b'),
(488, 92, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(489, 92, '_items_1_content', 'field_58d05f574d4a5'),
(490, 92, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(491, 92, '_items_1_images', 'field_58d0642e9bdea'),
(492, 92, 'items', '2'),
(493, 92, '_items', 'field_58d05f0bbfde7'),
(494, 92, 'delay', '8'),
(495, 92, '_delay', 'field_58d0624d7eb15'),
(496, 93, '_edit_last', '1'),
(497, 93, '_edit_lock', '1490069926:1'),
(498, 99, '_wp_attached_file', '2017/03/Membre.jpg'),
(499, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:300;s:6:"height";i:150;s:4:"file";s:18:"2017/03/Membre.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"Membre-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(500, 100, '_wp_attached_file', '2017/03/dyade-photo.jpg'),
(501, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:198;s:6:"height";i:193;s:4:"file";s:23:"2017/03/dyade-photo.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"dyade-photo-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(505, 56, 'items', ''),
(506, 56, '_items', 'field_58d05f0bbfde7'),
(507, 56, 'delay', '8'),
(508, 56, '_delay', 'field_58d0624d7eb15'),
(509, 103, 'items', ''),
(510, 103, '_items', 'field_58d05f0bbfde7'),
(511, 103, 'delay', '8'),
(512, 103, '_delay', 'field_58d0624d7eb15'),
(513, 56, '_thumbnail_id', '69'),
(516, 87, 'slides_0_title', ''),
(517, 87, '_slides_0_title', 'field_5910a92232889'),
(518, 87, 'slides_0_subtitle', ''),
(519, 87, '_slides_0_subtitle', 'field_5910a9483288a'),
(520, 87, 'slides_0_background', '70'),
(521, 87, '_slides_0_background', 'field_5910a9ca3288c'),
(522, 87, 'slides', '1'),
(523, 87, '_slides', 'field_5910a9633288b'),
(524, 87, 'auto_delay', '5'),
(525, 87, '_auto_delay', 'field_5910aa103288d'),
(526, 111, 'items_0_title', 'Les bobettes'),
(527, 111, '_items_0_title', 'field_58d064d3c471b'),
(528, 111, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(529, 111, '_items_0_content', 'field_58d05f574d4a5'),
(530, 111, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(531, 111, '_items_0_images', 'field_58d0642e9bdea'),
(532, 111, 'items_1_title', 'La collection zéro déchet'),
(533, 111, '_items_1_title', 'field_58d064d3c471b'),
(534, 111, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(535, 111, '_items_1_content', 'field_58d05f574d4a5'),
(536, 111, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(537, 111, '_items_1_images', 'field_58d0642e9bdea'),
(538, 111, 'items', '2'),
(539, 111, '_items', 'field_58d05f0bbfde7'),
(540, 111, 'delay', '8'),
(541, 111, '_delay', 'field_58d0624d7eb15'),
(542, 111, 'slides_0_title', ''),
(543, 111, '_slides_0_title', 'field_5910a92232889'),
(544, 111, 'slides_0_subtitle', ''),
(545, 111, '_slides_0_subtitle', 'field_5910a9483288a'),
(546, 111, 'slides_0_background', ''),
(547, 111, '_slides_0_background', 'field_5910a9ca3288c'),
(548, 111, 'slides', '1'),
(549, 111, '_slides', 'field_5910a9633288b'),
(550, 111, 'auto_delay', '5'),
(551, 111, '_auto_delay', 'field_5910aa103288d'),
(564, 112, 'items_0_title', 'Les bobettes'),
(565, 112, '_items_0_title', 'field_58d064d3c471b'),
(566, 112, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(567, 112, '_items_0_content', 'field_58d05f574d4a5'),
(568, 112, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(569, 112, '_items_0_images', 'field_58d0642e9bdea'),
(570, 112, 'items_1_title', 'La collection zéro déchet'),
(571, 112, '_items_1_title', 'field_58d064d3c471b'),
(572, 112, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(573, 112, '_items_1_content', 'field_58d05f574d4a5'),
(574, 112, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(575, 112, '_items_1_images', 'field_58d0642e9bdea'),
(576, 112, 'items', '2') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(577, 112, '_items', 'field_58d05f0bbfde7'),
(578, 112, 'delay', '8'),
(579, 112, '_delay', 'field_58d0624d7eb15'),
(580, 112, 'slides_0_title', 'Sous-vêtements éco-responsables pour hommes et femmes'),
(581, 112, '_slides_0_title', 'field_5910a92232889'),
(582, 112, 'slides_0_subtitle', 'et autres accessoires fabriqués à Montréal dans un environement zéro déchet'),
(583, 112, '_slides_0_subtitle', 'field_5910a9483288a'),
(584, 112, 'slides_0_background', '69'),
(585, 112, '_slides_0_background', 'field_5910a9ca3288c'),
(586, 112, 'slides', '3'),
(587, 112, '_slides', 'field_5910a9633288b'),
(588, 112, 'auto_delay', '5'),
(589, 112, '_auto_delay', 'field_5910aa103288d'),
(590, 112, 'slides_1_title', ''),
(591, 112, '_slides_1_title', 'field_5910a92232889'),
(592, 112, 'slides_1_subtitle', ''),
(593, 112, '_slides_1_subtitle', 'field_5910a9483288a'),
(594, 112, 'slides_1_background', '70'),
(595, 112, '_slides_1_background', 'field_5910a9ca3288c'),
(596, 112, 'slides_2_title', 'Blablabla'),
(597, 112, '_slides_2_title', 'field_5910a92232889'),
(598, 112, 'slides_2_subtitle', 'et re blabla'),
(599, 112, '_slides_2_subtitle', 'field_5910a9483288a'),
(600, 112, 'slides_2_background', '48'),
(601, 112, '_slides_2_background', 'field_5910a9ca3288c'),
(604, 116, '_wp_attached_file', '2017/03/bobette-o-vent-eco-creation.jpg'),
(605, 116, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:900;s:6:"height";i:600;s:4:"file";s:39:"2017/03/bobette-o-vent-eco-creation.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"bobette-o-vent-eco-creation-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:39:"bobette-o-vent-eco-creation-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:39:"bobette-o-vent-eco-creation-640x427.jpg";s:5:"width";i:640;s:6:"height";i:427;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"2.8";s:6:"credit";s:11:"Joshua Pool";s:6:"camera";s:21:"Canon EOS 5D Mark III";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1464193937";s:9:"copyright";s:19:"All Rights Reserved";s:12:"focal_length";s:2:"38";s:3:"iso";s:4:"6400";s:13:"shutter_speed";s:5:"0.005";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(606, 117, '_wp_attached_file', '2017/03/BR_dyade-photo-o-vent-decembre-1039.jpg'),
(607, 117, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1363;s:4:"file";s:47:"2017/03/BR_dyade-photo-o-vent-decembre-1039.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1039-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"BR_dyade-photo-o-vent-decembre-1039-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1039-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:49:"BR_dyade-photo-o-vent-decembre-1039-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1039-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"4";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1482681753";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"24";s:3:"iso";s:4:"1000";s:13:"shutter_speed";s:5:"0.004";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:2:{i:0;s:11:"dyade photo";i:1;s:10:"dyadephoto";}}}'),
(608, 118, '_wp_attached_file', '2017/03/BR_dyade-photo-o-vent-decembre-1056.jpg'),
(609, 118, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1363;s:4:"file";s:47:"2017/03/BR_dyade-photo-o-vent-decembre-1056.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1056-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"BR_dyade-photo-o-vent-decembre-1056-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1056-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:49:"BR_dyade-photo-o-vent-decembre-1056-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1056-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"4";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1482682227";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"24";s:3:"iso";s:4:"1600";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:2:{i:0;s:11:"dyade photo";i:1;s:10:"dyadephoto";}}}'),
(610, 119, '_wp_attached_file', '2017/03/BR_dyade-photo-o-vent-decembre-1067.jpg'),
(611, 119, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1363;s:4:"file";s:47:"2017/03/BR_dyade-photo-o-vent-decembre-1067.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1067-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"BR_dyade-photo-o-vent-decembre-1067-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1067-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:49:"BR_dyade-photo-o-vent-decembre-1067-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1067-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"5";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1482683085";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"500";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:2:{i:0;s:11:"dyade photo";i:1;s:10:"dyadephoto";}}}'),
(612, 120, '_wp_attached_file', '2017/03/BR_dyade-photo-o-vent-decembre-1079.jpg'),
(613, 120, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1363;s:4:"file";s:47:"2017/03/BR_dyade-photo-o-vent-decembre-1079.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1079-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"BR_dyade-photo-o-vent-decembre-1079-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1079-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:49:"BR_dyade-photo-o-vent-decembre-1079-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1079-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"5";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1482683120";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"24";s:3:"iso";s:3:"500";s:13:"shutter_speed";s:6:"0.0008";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:2:{i:0;s:11:"dyade photo";i:1;s:10:"dyadephoto";}}}'),
(614, 121, '_wp_attached_file', '2017/03/BR_dyade-photo-o-vent-decembre-1083.jpg'),
(615, 121, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2048;s:6:"height";i:1363;s:4:"file";s:47:"2017/03/BR_dyade-photo-o-vent-decembre-1083.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1083-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"BR_dyade-photo-o-vent-decembre-1083-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1083-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:49:"BR_dyade-photo-o-vent-decembre-1083-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:47:"BR_dyade-photo-o-vent-decembre-1083-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"5";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1482683150";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"24";s:3:"iso";s:3:"500";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:2:{i:0;s:11:"dyade photo";i:1;s:10:"dyadephoto";}}}'),
(618, 123, '_wp_attached_file', '2017/03/dyade-photo-ovent-2016-06-24.jpg'),
(619, 123, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2396;s:4:"file";s:40:"2017/03/dyade-photo-ovent-2016-06-24.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"dyade-photo-ovent-2016-06-24-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-24-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:40:"dyade-photo-ovent-2016-06-24-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-24-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:40:"dyade-photo-ovent-2016-06-24-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1466358120";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"45";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:5:"boxer";i:1;s:9:"caleçons";i:2;s:11:"dyade photo";i:3;s:10:"dyadephoto";i:4;s:5:"homme";i:5;s:10:"publicité";i:6;s:15:"sous-vêtements";i:7;s:5:"été";i:8;s:7:"ô vent";}}}'),
(620, 124, '_wp_attached_file', '2017/03/dyade-photo-ovent-2016-06-142.jpg'),
(621, 124, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2396;s:4:"file";s:41:"2017/03/dyade-photo-ovent-2016-06-142.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-142-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-142-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-142-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:43:"dyade-photo-ovent-2016-06-142-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-142-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"7.1";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1466360107";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:5:"boxer";i:1;s:9:"caleçons";i:2;s:11:"dyade photo";i:3;s:10:"dyadephoto";i:4;s:5:"homme";i:5;s:10:"publicité";i:6;s:15:"sous-vêtements";i:7;s:5:"été";i:8;s:7:"ô vent";}}}'),
(622, 125, '_wp_attached_file', '2017/03/dyade-photo-ovent-2016-06-796.jpg'),
(623, 125, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2396;s:4:"file";s:41:"2017/03/dyade-photo-ovent-2016-06-796.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-796-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-796-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-796-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:43:"dyade-photo-ovent-2016-06-796-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-796-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"7.1";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1466364069";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"24";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:5:"boxer";i:1;s:9:"caleçons";i:2;s:11:"dyade photo";i:3;s:10:"dyadephoto";i:4;s:5:"homme";i:5;s:10:"publicité";i:6;s:15:"sous-vêtements";i:7;s:5:"été";i:8;s:7:"ô vent";}}}'),
(624, 126, '_wp_attached_file', '2017/03/dyade-photo-ovent-2016-06-962.jpg'),
(625, 126, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2396;s:4:"file";s:41:"2017/03/dyade-photo-ovent-2016-06-962.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-962-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-962-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-962-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:43:"dyade-photo-ovent-2016-06-962-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-962-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1466364419";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"60";s:3:"iso";s:3:"400";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:5:"boxer";i:1;s:9:"caleçons";i:2;s:11:"dyade photo";i:3;s:10:"dyadephoto";i:4;s:5:"homme";i:5;s:10:"publicité";i:6;s:15:"sous-vêtements";i:7;s:5:"été";i:8;s:7:"ô vent";}}}'),
(626, 127, '_wp_attached_file', '2017/03/dyade-photo-ovent-2016-06-1086.jpg'),
(627, 127, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2396;s:4:"file";s:42:"2017/03/dyade-photo-ovent-2016-06-1086.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-1086-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"dyade-photo-ovent-2016-06-1086-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-1086-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:44:"dyade-photo-ovent-2016-06-1086-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-1086-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"6.3";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1466365765";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"70";s:3:"iso";s:3:"800";s:13:"shutter_speed";s:5:"0.001";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:5:"boxer";i:1;s:9:"caleçons";i:2;s:11:"dyade photo";i:3;s:10:"dyadephoto";i:4;s:5:"homme";i:5;s:10:"publicité";i:6;s:15:"sous-vêtements";i:7;s:5:"été";i:8;s:7:"ô vent";}}}'),
(628, 128, '_wp_attached_file', '2017/03/dyade-photo-ovent-2016-06-335.jpg'),
(629, 128, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3600;s:6:"height";i:2396;s:4:"file";s:41:"2017/03/dyade-photo-ovent-2016-06-335.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-335-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:42:"dyade-photo-ovent-2016-06-335-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-335-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:43:"dyade-photo-ovent-2016-06-335-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:41:"dyade-photo-ovent-2016-06-335-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"8";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1466359830";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"27";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:7:"0.00125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:9:{i:0;s:5:"boxer";i:1;s:9:"caleçons";i:2;s:11:"dyade photo";i:3;s:10:"dyadephoto";i:4;s:5:"homme";i:5;s:10:"publicité";i:6;s:15:"sous-vêtements";i:7;s:5:"été";i:8;s:7:"ô vent";}}}'),
(630, 129, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-1.jpg'),
(631, 129, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2520;s:6:"height";i:3982;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-1.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-1-1024x1618.jpg";s:5:"width";i:1024;s:6:"height";i:1618;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-1-768x1214.jpg";s:5:"width";i:768;s:6:"height";i:1214;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-1-1600x2528.jpg";s:5:"width";i:1600;s:6:"height";i:2528;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-1-640x1011.jpg";s:5:"width";i:640;s:6:"height";i:1011;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.8";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1454155293";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:3:"200";s:13:"shutter_speed";s:17:"0.033333333333333";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(632, 130, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-2.jpg'),
(633, 130, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2873;s:6:"height";i:4000;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-2.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-2-1024x1426.jpg";s:5:"width";i:1024;s:6:"height";i:1426;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-2-768x1069.jpg";s:5:"width";i:768;s:6:"height";i:1069;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-2-1600x2228.jpg";s:5:"width";i:1600;s:6:"height";i:2228;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-2-640x891.jpg";s:5:"width";i:640;s:6:"height";i:891;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.8";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1454155823";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:3:"800";s:13:"shutter_speed";s:3:"0.1";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(634, 131, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-3.jpg'),
(635, 131, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:4000;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-3.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-3-1024x1365.jpg";s:5:"width";i:1024;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-3-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-3-1600x2133.jpg";s:5:"width";i:1600;s:6:"height";i:2133;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-3-640x853.jpg";s:5:"width";i:640;s:6:"height";i:853;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.8";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1454156624";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:3:"800";s:13:"shutter_speed";s:3:"0.1";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(636, 132, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-4.jpg'),
(637, 132, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3000;s:6:"height";i:4000;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-4.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-4-1024x1365.jpg";s:5:"width";i:1024;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-4-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-4-1600x2133.jpg";s:5:"width";i:1600;s:6:"height";i:2133;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-4-640x853.jpg";s:5:"width";i:640;s:6:"height";i:853;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.8";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1454156686";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:3:"800";s:13:"shutter_speed";s:3:"0.1";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(638, 133, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-5.jpg'),
(639, 133, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4000;s:6:"height";i:2784;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-5.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-5-1024x713.jpg";s:5:"width";i:1024;s:6:"height";i:713;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-5-768x535.jpg";s:5:"width";i:768;s:6:"height";i:535;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-5-1600x1114.jpg";s:5:"width";i:1600;s:6:"height";i:1114;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-5-640x445.jpg";s:5:"width";i:640;s:6:"height";i:445;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"1.8";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1474207442";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:3:"800";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(640, 134, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-6.jpg'),
(641, 134, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2992;s:6:"height";i:2992;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-6.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-6-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-6-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-6-1600x1600.jpg";s:5:"width";i:1600;s:6:"height";i:1600;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-6-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"2";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1486650752";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:4:"1600";s:13:"shutter_speed";s:6:"0.0125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(642, 135, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-7.jpg'),
(643, 135, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2992;s:6:"height";i:2992;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-7.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-7-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-7-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-7-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-7-1600x1600.jpg";s:5:"width";i:1600;s:6:"height";i:1600;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-7-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"2";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1486651240";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:4:"1600";s:13:"shutter_speed";s:4:"0.01";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(644, 136, '_wp_attached_file', '2017/03/o-vent-sacs-vrac-8.jpg'),
(645, 136, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2992;s:6:"height";i:2591;s:4:"file";s:30:"2017/03/o-vent-sacs-vrac-8.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-8-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"o-vent-sacs-vrac-8-1024x887.jpg";s:5:"width";i:1024;s:6:"height";i:887;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-8-768x665.jpg";s:5:"width";i:768;s:6:"height";i:665;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"o-vent-sacs-vrac-8-1600x1386.jpg";s:5:"width";i:1600;s:6:"height";i:1386;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:30:"o-vent-sacs-vrac-8-640x554.jpg";s:5:"width";i:640;s:6:"height";i:554;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"2";s:6:"credit";s:0:"";s:6:"camera";s:19:"Canon PowerShot G15";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1490781336";s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.1";s:3:"iso";s:4:"1600";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(646, 87, '_thumbnail_id', '116'),
(647, 138, 'items_0_title', 'Les bobettes'),
(648, 138, '_items_0_title', 'field_58d064d3c471b'),
(649, 138, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(650, 138, '_items_0_content', 'field_58d05f574d4a5'),
(651, 138, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(652, 138, '_items_0_images', 'field_58d0642e9bdea'),
(653, 138, 'items_1_title', 'La collection zéro déchet'),
(654, 138, '_items_1_title', 'field_58d064d3c471b'),
(655, 138, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(656, 138, '_items_1_content', 'field_58d05f574d4a5'),
(657, 138, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(658, 138, '_items_1_images', 'field_58d0642e9bdea'),
(659, 138, 'items', '2'),
(660, 138, '_items', 'field_58d05f0bbfde7'),
(661, 138, 'delay', '8'),
(662, 138, '_delay', 'field_58d0624d7eb15'),
(663, 138, 'slides_0_title', 'Sous-vêtements éco-responsables pour hommes et femmes'),
(664, 138, '_slides_0_title', 'field_5910a92232889'),
(665, 138, 'slides_0_subtitle', 'et autres accessoires fabriqués à Montréal dans un environement zéro déchet'),
(666, 138, '_slides_0_subtitle', 'field_5910a9483288a'),
(667, 138, 'slides_0_background', '69'),
(668, 138, '_slides_0_background', 'field_5910a9ca3288c'),
(669, 138, 'slides', '3'),
(670, 138, '_slides', 'field_5910a9633288b'),
(671, 138, 'auto_delay', '5'),
(672, 138, '_auto_delay', 'field_5910aa103288d'),
(673, 138, 'slides_1_title', ''),
(674, 138, '_slides_1_title', 'field_5910a92232889'),
(675, 138, 'slides_1_subtitle', ''),
(676, 138, '_slides_1_subtitle', 'field_5910a9483288a'),
(677, 138, 'slides_1_background', '70'),
(678, 138, '_slides_1_background', 'field_5910a9ca3288c'),
(679, 138, 'slides_2_title', 'Blablabla'),
(680, 138, '_slides_2_title', 'field_5910a92232889') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(681, 138, 'slides_2_subtitle', 'et re blabla'),
(682, 138, '_slides_2_subtitle', 'field_5910a9483288a'),
(683, 138, 'slides_2_background', '48'),
(684, 138, '_slides_2_background', 'field_5910a9ca3288c'),
(685, 139, 'items_0_title', 'Les bobettes'),
(686, 139, '_items_0_title', 'field_58d064d3c471b'),
(687, 139, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(688, 139, '_items_0_content', 'field_58d05f574d4a5'),
(689, 139, 'items_0_images', 'a:2:{i:0;s:2:"69";i:1;s:2:"71";}'),
(690, 139, '_items_0_images', 'field_58d0642e9bdea'),
(691, 139, 'items_1_title', 'La collection zéro déchet'),
(692, 139, '_items_1_title', 'field_58d064d3c471b'),
(693, 139, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(694, 139, '_items_1_content', 'field_58d05f574d4a5'),
(695, 139, 'items_1_images', 'a:3:{i:0;s:2:"70";i:1;s:2:"48";i:2;s:2:"71";}'),
(696, 139, '_items_1_images', 'field_58d0642e9bdea'),
(697, 139, 'items', '2'),
(698, 139, '_items', 'field_58d05f0bbfde7'),
(699, 139, 'delay', '8'),
(700, 139, '_delay', 'field_58d0624d7eb15'),
(701, 139, 'slides_0_title', ''),
(702, 139, '_slides_0_title', 'field_5910a92232889'),
(703, 139, 'slides_0_subtitle', ''),
(704, 139, '_slides_0_subtitle', 'field_5910a9483288a'),
(705, 139, 'slides_0_background', '70'),
(706, 139, '_slides_0_background', 'field_5910a9ca3288c'),
(707, 139, 'slides', '1'),
(708, 139, '_slides', 'field_5910a9633288b'),
(709, 139, 'auto_delay', '5'),
(710, 139, '_auto_delay', 'field_5910aa103288d'),
(720, 140, 'items_0_title', 'Les bobettes'),
(721, 140, '_items_0_title', 'field_58d064d3c471b'),
(722, 140, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(723, 140, '_items_0_content', 'field_58d05f574d4a5'),
(724, 140, 'items_0_images', 'a:13:{i:0;s:3:"136";i:1;s:3:"128";i:2;s:3:"127";i:3;s:3:"126";i:4;s:3:"125";i:5;s:3:"124";i:6;s:3:"123";i:7;s:3:"122";i:8;s:3:"121";i:9;s:3:"120";i:10;s:3:"119";i:11;s:3:"118";i:12;s:3:"117";}'),
(725, 140, '_items_0_images', 'field_58d0642e9bdea'),
(726, 140, 'items_1_title', 'La collection zéro déchet'),
(727, 140, '_items_1_title', 'field_58d064d3c471b'),
(728, 140, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(729, 140, '_items_1_content', 'field_58d05f574d4a5'),
(730, 140, 'items_1_images', 'a:8:{i:0;s:3:"136";i:1;s:3:"135";i:2;s:3:"134";i:3;s:3:"133";i:4;s:3:"132";i:5;s:3:"131";i:6;s:3:"130";i:7;s:3:"129";}'),
(731, 140, '_items_1_images', 'field_58d0642e9bdea'),
(732, 140, 'items', '2'),
(733, 140, '_items', 'field_58d05f0bbfde7'),
(734, 140, 'delay', '8'),
(735, 140, '_delay', 'field_58d0624d7eb15'),
(736, 140, 'slides_0_title', ''),
(737, 140, '_slides_0_title', 'field_5910a92232889'),
(738, 140, 'slides_0_subtitle', ''),
(739, 140, '_slides_0_subtitle', 'field_5910a9483288a'),
(740, 140, 'slides_0_background', '70'),
(741, 140, '_slides_0_background', 'field_5910a9ca3288c'),
(742, 140, 'slides', '1'),
(743, 140, '_slides', 'field_5910a9633288b'),
(744, 140, 'auto_delay', '5'),
(745, 140, '_auto_delay', 'field_5910aa103288d'),
(746, 141, 'items_0_title', 'Les bobettes'),
(747, 141, '_items_0_title', 'field_58d064d3c471b'),
(748, 141, 'items_0_content', 'Trouver un jolis texte pour aller avec ces belles images de bobettes ;)'),
(749, 141, '_items_0_content', 'field_58d05f574d4a5'),
(750, 141, 'items_0_images', 'a:11:{i:0;s:3:"128";i:1;s:3:"127";i:2;s:3:"126";i:3;s:3:"125";i:4;s:3:"124";i:5;s:3:"123";i:6;s:3:"121";i:7;s:3:"120";i:8;s:3:"119";i:9;s:3:"118";i:10;s:3:"117";}'),
(751, 141, '_items_0_images', 'field_58d0642e9bdea'),
(752, 141, 'items_1_title', 'La collection zéro déchet'),
(753, 141, '_items_1_title', 'field_58d064d3c471b'),
(754, 141, 'items_1_content', 'Des sacs et tout le tralala - que l\'on achette qu\'une fois et qu\'on amene avec soi'),
(755, 141, '_items_1_content', 'field_58d05f574d4a5'),
(756, 141, 'items_1_images', 'a:8:{i:0;s:3:"136";i:1;s:3:"135";i:2;s:3:"134";i:3;s:3:"133";i:4;s:3:"132";i:5;s:3:"131";i:6;s:3:"130";i:7;s:3:"129";}'),
(757, 141, '_items_1_images', 'field_58d0642e9bdea'),
(758, 141, 'items', '2'),
(759, 141, '_items', 'field_58d05f0bbfde7'),
(760, 141, 'delay', '8'),
(761, 141, '_delay', 'field_58d0624d7eb15'),
(762, 141, 'slides_0_title', ''),
(763, 141, '_slides_0_title', 'field_5910a92232889'),
(764, 141, 'slides_0_subtitle', ''),
(765, 141, '_slides_0_subtitle', 'field_5910a9483288a'),
(766, 141, 'slides_0_background', '70'),
(767, 141, '_slides_0_background', 'field_5910a9ca3288c'),
(768, 141, 'slides', '1'),
(769, 141, '_slides', 'field_5910a9633288b'),
(770, 141, 'auto_delay', '5'),
(771, 141, '_auto_delay', 'field_5910aa103288d'),
(772, 142, '_wp_attached_file', '2017/07/ovent_2015-04-01-2301.jpg'),
(773, 142, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:4292;s:6:"height";i:2857;s:4:"file";s:33:"2017/07/ovent_2015-04-01-2301.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"ovent_2015-04-01-2301-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"ovent_2015-04-01-2301-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:33:"ovent_2015-04-01-2301-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:35:"ovent_2015-04-01-2301-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:33:"ovent_2015-04-01-2301-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"3.2";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1427900103";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"70";s:3:"iso";s:4:"1600";s:13:"shutter_speed";s:9:"0.0015625";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:8:{i:0;s:7:"culotte";i:1;s:10:"dyadephoto";i:2;s:5:"jeans";i:3;s:9:"kangourou";i:4;s:4:"loft";i:5;s:4:"mode";i:6;s:9:"vêtement";i:7;s:7:"ô vent";}}}'),
(774, 143, '_wp_attached_file', '2017/07/ovent_2015-04-01-1634.jpg'),
(775, 143, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3845;s:6:"height";i:2559;s:4:"file";s:33:"2017/07/ovent_2015-04-01-1634.jpg";s:5:"sizes";a:5:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"ovent_2015-04-01-1634-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:34:"ovent_2015-04-01-1634-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:33:"ovent_2015-04-01-1634-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:35:"ovent_2015-04-01-1634-1600x1065.jpg";s:5:"width";i:1600;s:6:"height";i:1065;s:9:"mime-type";s:10:"image/jpeg";}s:5:"small";a:4:{s:4:"file";s:33:"ovent_2015-04-01-1634-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:3:"2.8";s:6:"credit";s:13:"Patrick Dubuc";s:6:"camera";s:8:"NIKON D4";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1427895605";s:9:"copyright";s:12:"©Dyadephoto";s:12:"focal_length";s:2:"70";s:3:"iso";s:4:"1600";s:13:"shutter_speed";s:8:"0.003125";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:8:{i:0;s:7:"culotte";i:1;s:10:"dyadephoto";i:2;s:5:"jeans";i:3;s:9:"kangourou";i:4;s:4:"loft";i:5;s:4:"mode";i:6;s:9:"vêtement";i:7;s:7:"ô vent";}}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=145 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2017-03-05 00:17:02', '2017-03-04 23:17:02', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous!', 'Bonjour tout le monde&nbsp;!', '', 'publish', 'open', 'open', '', 'bonjour-tout-le-monde', '', '', '2017-03-05 00:17:02', '2017-03-04 23:17:02', '', 0, 'http://ovent.busbz.com/?p=1', 0, 'post', '', 1),
(4, 1, '2017-03-05 01:01:00', '2017-03-05 00:01:00', '', 'polylang_mo_2', '', 'private', 'closed', 'closed', '', 'polylang_mo_2', '', '', '2017-03-05 01:01:00', '2017-03-05 00:01:00', '', 0, 'http://ovent.busbz.com/?post_type=polylang_mo&p=4', 0, 'polylang_mo', '', 0),
(7, 1, '2017-03-12 18:18:36', '2017-03-12 17:18:36', '', 'polylang_mo_6', '', 'private', 'closed', 'closed', '', 'polylang_mo_6', '', '', '2017-03-12 18:18:36', '2017-03-12 17:18:36', '', 0, 'http://ovent.busbz.com/?post_type=polylang_mo&p=7', 0, 'polylang_mo', '', 0),
(8, 1, '2017-03-12 18:20:26', '2017-03-12 17:20:26', 'Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank" rel="noopener noreferrer">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank" rel="noopener noreferrer">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank" rel="noopener noreferrer">[facebook]</a>', 'La créatrice', '', 'publish', 'closed', 'closed', '', 'biographie', '', '', '2017-05-25 01:29:00', '2017-05-25 00:29:00', '', 0, 'http://ovent.busbz.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2017-03-12 18:20:26', '2017-03-12 17:20:26', 'Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com/" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'biographie', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-12 18:20:26', '2017-03-12 17:20:26', '', 8, 'http://ovent.busbz.com/2017/03/12/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2017-03-12 18:20:54', '2017-03-12 17:20:54', 'Young artist surfing through the wind and ideas that she picks up in the clouds, she is passionate about the huge potential that stems from environmental issues. You’ll find her testing the limits of her sewing machine or in the middle of a culinary exploration on Saturday, or any day of the week for that matter. She creates with no single objective besides (and I quote her) to “see what will happen.”\r\n\r\nWith these few clues, some might be tempted to think that she’s a fashion designer with a hippy side but in fact she’s much more than that.\r\n\r\nSo, who is she? Her name is Ericka, she’s an eco-creator and she lets her imagination fly with the blowing wind while keeping her two feet solidly on the ground. She has a deep conviction: She exists to create. And she creates to make a better world, one idea at a time.\r\n\r\nWinter 2015. It’s cold outside but it’s Montreal so nothing is out of the ordinary. And everything would have stayed normal if a draft of air had not whistled gently in her ears. She needed to do something to calm down the growing tension that pulses through the world. It’s through this desire for simplicity and lightness in this crazy planet that Ô vent was born.\r\n\r\nPhoto credit: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com/" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'Biography', '', 'publish', 'closed', 'closed', '', 'biography', '', '', '2017-03-20 06:28:09', '2017-03-20 05:28:09', '', 0, 'http://ovent.busbz.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2017-03-12 18:20:54', '2017-03-12 17:20:54', 'Young artist surfing through the wind and ideas that she picks up in the clouds, she is passionate about the huge potential that stems from environmental issues. You’ll find her testing the limits of her sewing machine or in the middle of a culinary exploration on Saturday, or any day of the week for that matter. She creates with no single objective besides (and I quote her) to “see what will happen.”\r\n\r\nWith these few clues, some might be tempted to think that she’s a fashion designer with a hippy side but in fact she’s much more than that.\r\n\r\nSo, who is she? Her name is Ericka, she’s an eco-creator and she lets her imagination fly with the blowing wind while keeping her two feet solidly on the ground. She has a deep conviction: She exists to create. And she creates to make a better world, one idea at a time.\r\n\r\nWinter 2015. It’s cold outside but it’s Montreal so nothing is out of the ordinary. And everything would have stayed normal if a draft of air had not whistled gently in her ears. She needed to do something to calm down the growing tension that pulses through the world. It’s through this desire for simplicity and lightness in this crazy planet that Ô vent was born.\r\n\r\nPhoto credit: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com/" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'Biography', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2017-03-12 18:20:54', '2017-03-12 17:20:54', '', 10, 'http://ovent.busbz.com/2017/03/12/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2017-03-12 18:49:21', '2017-03-12 17:49:21', '<p style="text-align: justify; text-justify: inter-word;"><img class="alignright wp-image-191 " src="http://o-vent.com/wp-content/uploads/2015/03/photo-site-o-vent-bio1.png" alt="photo site o vent bio" width="586" height="390" /></p>\r\n<p style="text-align: justify; text-justify: inter-word;">Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”</p>\r\n<p style="text-align: justify; text-justify: inter-word;">Avec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.</p>\r\n<p style="text-align: justify; text-justify: inter-word;">Pour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.</p>\r\n<p style="text-align: justify; text-justify: inter-word;">Hiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.</p>\r\n<p style="text-align: justify; text-justify: inter-word;">Crédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a></p>', 'biographie', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-12 18:49:21', '2017-03-12 17:49:21', '', 8, 'http://ovent.busbz.com/2017/03/12/8-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2017-03-19 21:49:55', '2017-03-19 20:49:55', '<p class="no-margin"><img class="alignright wp-image-191 " src="http://o-vent.com/wp-content/uploads/2015/03/photo-site-o-vent-bio1.png" alt="photo site o vent bio" width="586" height="390" /></p>\n\n\nJeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\n\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\n\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\n\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\n\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'Biographie', '', 'inherit', 'closed', 'closed', '', '8-autosave-v1', '', '', '2017-03-19 21:49:55', '2017-03-19 20:49:55', '', 8, 'http://ovent.busbz.com/2017/03/12/8-autosave-v1/', 0, 'revision', '', 0),
(14, 1, '2017-03-12 18:55:01', '2017-03-12 17:55:01', '<img class="alignright wp-image-191 " src="http://o-vent.com/wp-content/uploads/2015/03/photo-site-o-vent-bio1.png" alt="photo site o vent bio" width="586" height="390" />\r\nJeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'biographie', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-12 18:55:01', '2017-03-12 17:55:01', '', 8, 'http://ovent.busbz.com/2017/03/12/8-revision-v1/', 0, 'revision', '', 0),
(15, 1, '2017-03-12 18:56:44', '2017-03-12 17:56:44', ' ', '', '', 'publish', 'closed', 'closed', '', '15', '', '', '2017-03-21 00:45:58', '2017-03-20 23:45:58', '', 0, 'http://ovent.busbz.com/?p=15', 2, 'nav_menu_item', '', 0),
(16, 1, '2017-03-12 18:56:44', '2017-03-12 17:56:44', '', 'Language switcher', '', 'publish', 'closed', 'closed', '', 'language-switcher', '', '', '2017-03-21 00:45:58', '2017-03-20 23:45:58', '', 0, 'http://ovent.busbz.com/?p=16', 5, 'nav_menu_item', '', 0),
(18, 1, '2017-03-14 02:52:31', '2017-03-14 01:52:31', '[shops]', 'Points de vente', '', 'publish', 'closed', 'closed', '', 'points-de-vente', '', '', '2017-03-19 18:19:24', '2017-03-19 17:19:24', '', 0, 'http://ovent.busbz.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2017-03-14 02:51:50', '2017-03-14 01:51:50', '[shops]', 'Retail locations', '', 'publish', 'closed', 'closed', '', 'retail-locations', '', '', '2017-03-20 06:29:16', '2017-03-20 05:29:16', '', 0, 'http://ovent.busbz.com/?page_id=19', 0, 'page', '', 0),
(20, 1, '2017-03-14 02:51:50', '2017-03-14 01:51:50', '', 'retail locations', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-03-14 02:51:50', '2017-03-14 01:51:50', '', 19, 'http://ovent.busbz.com/2017/03/14/19-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2017-03-14 02:52:31', '2017-03-14 01:52:31', '', 'Points de vente', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-03-14 02:52:31', '2017-03-14 01:52:31', '', 18, 'http://ovent.busbz.com/2017/03/14/18-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2017-03-14 02:53:46', '2017-03-14 01:53:46', ' ', '', '', 'publish', 'closed', 'closed', '', '22', '', '', '2017-03-21 00:45:58', '2017-03-20 23:45:58', '', 0, 'http://ovent.busbz.com/?p=22', 3, 'nav_menu_item', '', 0),
(23, 1, '2017-03-14 02:53:46', '2017-03-14 01:53:46', '', 'Boutique en ligne', '', 'publish', 'closed', 'closed', '', 'boutique-en-ligne', '', '', '2017-03-21 00:45:58', '2017-03-20 23:45:58', '', 0, 'http://ovent.busbz.com/?p=23', 4, 'nav_menu_item', '', 0),
(24, 1, '2017-03-14 02:55:21', '2017-03-14 01:55:21', '', 'Language switcher', '', 'publish', 'closed', 'closed', '', 'language-switcher-2', '', '', '2017-03-20 23:59:07', '2017-03-20 22:59:07', '', 0, 'http://ovent.busbz.com/?p=24', 5, 'nav_menu_item', '', 0),
(25, 1, '2017-03-14 02:55:21', '2017-03-14 01:55:21', ' ', '', '', 'publish', 'closed', 'closed', '', '25', '', '', '2017-03-20 23:59:07', '2017-03-20 22:59:07', '', 0, 'http://ovent.busbz.com/?p=25', 3, 'nav_menu_item', '', 0),
(27, 1, '2017-03-14 02:55:21', '2017-03-14 01:55:21', '', 'Online store', '', 'publish', 'closed', 'closed', '', 'online-store', '', '', '2017-03-20 23:59:07', '2017-03-20 22:59:07', '', 0, 'http://ovent.busbz.com/?p=27', 4, 'nav_menu_item', '', 0),
(28, 1, '2017-03-14 05:20:36', '2017-03-14 04:20:36', '<p class="no-margin"><img class="alignright wp-image-191 " src="http://o-vent.com/wp-content/uploads/2015/03/photo-site-o-vent-bio1.png" alt="photo site o vent bio" width="586" height="390" /></p>\r\n\r\nJeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'biographie', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-14 05:20:36', '2017-03-14 04:20:36', '', 8, 'http://ovent.busbz.com/2017/03/14/8-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2017-03-18 21:18:23', '2017-03-18 20:18:23', '', 'Le 5e (Café zéro déchet)', '', 'publish', 'closed', 'closed', '', 'le-5e-cafe-zero-dechet', '', '', '2017-03-18 21:44:38', '2017-03-18 20:44:38', '', 0, 'http://ovent.busbz.com/?post_type=shop&#038;p=31', 0, 'shop', '', 0),
(32, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"shop";}}}s:8:"position";s:15:"acf_after_title";s:5:"style";s:8:"seamless";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:2:{i:0;s:11:"the_content";i:1;s:7:"excerpt";}s:11:"description";s:34:"Ajout de champs pour les boutiques";}', 'Boutique', 'boutique', 'publish', 'closed', 'closed', '', 'group_58cd961f82922', '', '', '2017-03-18 22:20:04', '2017-03-18 21:20:04', '', 0, 'http://ovent.busbz.com/?post_type=acf-field-group&#038;p=32', 0, 'acf-field-group', '', 0),
(33, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:17:"(première ligne)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Adresse', 'address', 'publish', 'closed', 'closed', '', 'field_58cd962fa0b1b', '', '', '2017-03-18 21:31:27', '2017-03-18 20:31:27', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=33', 1, 'acf-field', '', 0),
(34, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:15:"(seconde ligne)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Ville', 'address_bis', 'publish', 'closed', 'closed', '', 'field_58cd966fa0b1c', '', '', '2017-03-18 21:31:41', '2017-03-18 20:31:41', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=34', 2, 'acf-field', '', 0),
(35, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:7:"http://";}', 'Site internet', 'web', 'publish', 'closed', 'closed', '', 'field_58cd9685a0b1d', '', '', '2017-03-18 21:29:54', '2017-03-18 20:29:54', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=35', 5, 'acf-field', '', 0),
(36, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:9:{s:4:"type";s:5:"email";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:10:"(optionel)";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Courriel', 'email', 'publish', 'closed', 'closed', '', 'field_58cd96b3a0b1e', '', '', '2017-03-18 21:27:06', '2017-03-18 20:27:06', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=36', 6, 'acf-field', '', 0),
(37, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:10:"(optionel)";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Téléphone', 'phone', 'publish', 'closed', 'closed', '', 'field_58cd96c6a0b1f', '', '', '2017-03-18 21:29:21', '2017-03-18 20:29:21', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=37', 7, 'acf-field', '', 0),
(38, 1, '2017-03-18 21:23:06', '2017-03-18 20:23:06', 'a:9:{s:4:"type";s:10:"google_map";s:12:"instructions";s:66:"Choisis ton adresse et ajuste en dragguant la pin qui apparaîtra.";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:10:"center_lat";s:0:"";s:10:"center_lng";s:0:"";s:4:"zoom";s:0:"";s:6:"height";s:0:"";}', 'Carte', 'map', 'publish', 'closed', 'closed', '', 'field_58cd96e4a0b20', '', '', '2017-03-18 21:28:48', '2017-03-18 20:28:48', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=38', 3, 'acf-field', '', 0),
(39, 1, '2017-03-18 21:27:06', '2017-03-18 20:27:06', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Adresse', 'adresse', 'publish', 'closed', 'closed', '', 'field_58cd97ecaabf5', '', '', '2017-03-18 21:27:06', '2017-03-18 20:27:06', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&p=39', 0, 'acf-field', '', 0),
(40, 1, '2017-03-18 21:27:06', '2017-03-18 20:27:06', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'extra', 'adresse_copy', 'publish', 'closed', 'closed', '', 'field_58cd9806aabf6', '', '', '2017-03-18 21:27:06', '2017-03-18 20:27:06', '', 32, 'http://ovent.busbz.com/?post_type=acf-field&p=40', 4, 'acf-field', '', 0),
(41, 1, '2017-03-18 21:45:13', '2017-03-18 20:45:13', '', 'À l\'atelier (sur rdv seulement)', '', 'publish', 'closed', 'closed', '', 'a-latelier-sur-rdv-seulement', '', '', '2017-03-18 21:45:13', '2017-03-18 20:45:13', '', 0, 'http://ovent.busbz.com/?post_type=shop&#038;p=41', 0, 'shop', '', 0),
(42, 1, '2017-03-18 21:45:49', '2017-03-18 20:45:49', '', 'La gaillarde', '', 'publish', 'closed', 'closed', '', 'la-gaillarde', '', '', '2017-03-18 21:45:49', '2017-03-18 20:45:49', '', 0, 'http://ovent.busbz.com/?post_type=shop&#038;p=42', 0, 'shop', '', 0),
(44, 1, '2017-03-18 22:17:08', '2017-03-18 21:17:08', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"post_template";s:8:"operator";s:2:"==";s:5:"value";s:18:"template-shops.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:68:"Ajout d\'un selecteur de boutique pour les pages de template Boutique";}', 'Points de vente', 'points-de-vente', 'publish', 'closed', 'closed', '', 'group_58cda39574b81', '', '', '2017-03-18 22:19:39', '2017-03-18 21:19:39', '', 0, 'http://ovent.busbz.com/?post_type=acf-field-group&#038;p=44', 0, 'acf-field-group', '', 0),
(45, 1, '2017-03-18 22:17:08', '2017-03-18 21:17:08', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:4:"shop";}s:8:"taxonomy";a:0:{}s:7:"filters";a:1:{i:0;s:6:"search";}s:8:"elements";s:0:"";s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Boutiques affichées', 'shops', 'publish', 'closed', 'closed', '', 'field_58cda3ad9afe3', '', '', '2017-03-18 22:18:18', '2017-03-18 21:18:18', '', 44, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=45', 0, 'acf-field', '', 0),
(46, 1, '2017-03-18 22:20:40', '2017-03-18 21:20:40', '[shops]', 'Points de vente', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-03-18 22:20:40', '2017-03-18 21:20:40', '', 18, 'http://ovent.busbz.com/2017/03/18/18-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2017-03-19 18:19:24', '2017-03-19 17:19:24', '[shops]', 'Points de vente', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2017-03-19 18:19:24', '2017-03-19 17:19:24', '', 18, 'http://ovent.busbz.com/2017/03/19/18-revision-v1/', 0, 'revision', '', 0),
(48, 1, '2017-03-19 21:50:08', '2017-03-19 20:50:08', '', 'photo-site-o-vent-bio1', '', 'inherit', 'open', 'closed', '', 'photo-site-o-vent-bio1', '', '', '2017-05-08 18:33:20', '2017-05-08 17:33:20', '', 8, 'http://ovent.busbz.com/wp-content/uploads/2017/03/photo-site-o-vent-bio1.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2017-03-19 21:50:18', '2017-03-19 20:50:18', 'Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'Biographie', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-19 21:50:18', '2017-03-19 20:50:18', '', 8, 'http://ovent.busbz.com/2017/03/19/8-revision-v1/', 0, 'revision', '', 0),
(50, 1, '2017-03-20 06:03:01', '2017-03-20 05:03:01', 'Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'LA CRÉATRICE', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-20 06:03:01', '2017-03-20 05:03:01', '', 8, 'http://ovent.busbz.com/2017/03/20/8-revision-v1/', 0, 'revision', '', 0),
(51, 1, '2017-03-20 06:03:08', '2017-03-20 05:03:08', 'Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank">[facebook]</a>', 'La créatrice', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-03-20 06:03:08', '2017-03-20 05:03:08', '', 8, 'http://ovent.busbz.com/2017/03/20/8-revision-v1/', 0, 'revision', '', 0),
(52, 1, '2017-03-20 06:26:27', '2017-03-20 05:26:27', ' ', '', '', 'publish', 'closed', 'closed', '', '52', '', '', '2017-03-20 23:59:07', '2017-03-20 22:59:07', '', 0, 'http://ovent.busbz.com/?p=52', 2, 'nav_menu_item', '', 0),
(53, 1, '2017-03-20 06:28:59', '2017-03-20 05:28:59', '[shops]', 'Retail locations', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-03-20 06:28:59', '2017-03-20 05:28:59', '', 19, 'http://ovent.busbz.com/2017/03/20/19-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2017-03-20 06:29:16', '2017-03-20 05:29:16', '[shops]', 'Retail locations', '', 'inherit', 'closed', 'closed', '', '19-revision-v1', '', '', '2017-03-20 06:29:16', '2017-03-20 05:29:16', '', 19, 'http://ovent.busbz.com/2017/03/20/19-revision-v1/', 0, 'revision', '', 0),
(56, 1, '2017-03-20 23:56:37', '2017-03-20 22:56:37', '<h1>Sous-vêtements éco-responsables\r\npour hommes et femmes</h1>\r\n<h2>et autres accessoires fabriqués à Montréal\r\ndans un environement zéro déchet</h2>', 'Ô vent', '', 'publish', 'closed', 'open', '', 'o-vent-2', '', '', '2017-03-27 18:14:07', '2017-03-27 17:14:07', '', 0, 'http://ovent.busbz.com/?page_id=56', 0, 'page', '', 0),
(57, 1, '2017-03-20 23:56:37', '2017-03-20 22:56:37', '', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-03-20 23:56:37', '2017-03-20 22:56:37', '', 56, 'http://ovent.busbz.com/2017/03/20/56-revision-v1/', 0, 'revision', '', 0),
(58, 1, '2017-03-20 23:58:33', '2017-03-20 22:58:33', '', 'Ô vent (en)', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-03-20 23:58:33', '2017-03-20 22:58:33', '', 56, 'http://ovent.busbz.com/2017/03/20/56-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2017-03-20 23:58:42', '2017-03-20 22:58:42', '', 'O vent', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-03-20 23:58:42', '2017-03-20 22:58:42', '', 56, 'http://ovent.busbz.com/2017/03/20/56-revision-v1/', 0, 'revision', '', 0),
(60, 1, '2017-03-20 23:59:07', '2017-03-20 22:59:07', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2017-03-20 23:59:07', '2017-03-20 22:59:07', '', 0, 'http://ovent.busbz.com/?p=60', 1, 'nav_menu_item', '', 0),
(62, 1, '2017-03-21 00:00:07', '2017-03-20 23:00:07', '', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-03-21 00:00:07', '2017-03-20 23:00:07', '', 56, 'http://ovent.busbz.com/2017/03/21/56-revision-v1/', 0, 'revision', '', 0),
(63, 1, '2017-03-21 00:00:58', '2017-03-20 23:00:58', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:17:"template-home.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Contenus suplémentaire', 'contenus-suplementaire', 'publish', 'closed', 'closed', '', 'group_58d05f045da36', '', '', '2017-07-05 20:36:50', '2017-07-05 19:36:50', '', 0, 'http://ovent.busbz.com/?post_type=acf-field-group&#038;p=63', 0, 'acf-field-group', '', 0),
(64, 1, '2017-03-21 00:00:58', '2017-03-20 23:00:58', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:99:"Pour les boutons avec slideshow\r\n(Vous pouvez afficher/masquer les details via la flèche a droite)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:19:"field_58d064d3c471b";s:3:"min";s:0:"";s:3:"max";i:2;s:6:"layout";s:5:"block";s:12:"button_label";s:0:"";}', 'Contenus', 'items', 'publish', 'closed', 'closed', '', 'field_58d05f0bbfde7', '', '', '2017-03-21 00:31:29', '2017-03-20 23:31:29', '', 63, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=64', 0, 'acf-field', '', 0),
(69, 1, '2017-03-21 00:08:43', '2017-03-20 23:08:43', '', 'o-vent-pret-a-porter', '', 'inherit', 'open', 'closed', '', 'o-vent-pret-a-porter', '', '', '2017-05-08 18:33:59', '2017-05-08 17:33:59', '', 87, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-pret-a-porter.png', 0, 'attachment', 'image/png', 0),
(70, 1, '2017-03-21 00:08:44', '2017-03-20 23:08:44', '', 'o-vent-reparation', '', 'inherit', 'open', 'closed', '', 'o-vent-reparation', '', '', '2017-05-08 18:33:59', '2017-05-08 17:33:59', '', 87, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-reparation.png', 0, 'attachment', 'image/png', 0),
(71, 1, '2017-03-21 00:08:45', '2017-03-20 23:08:45', '', 'o-vent-sur-mesure', '', 'inherit', 'open', 'closed', '', 'o-vent-sur-mesure', '', '', '2017-03-21 00:45:31', '2017-03-20 23:45:31', '', 0, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sur-mesure.png', 0, 'attachment', 'image/png', 0),
(75, 1, '2017-03-21 00:23:18', '2017-03-20 23:23:18', 'a:16:{s:4:"type";s:7:"gallery";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"insert";s:6:"append";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Images', 'images', 'publish', 'closed', 'closed', '', 'field_58d0642e9bdea', '', '', '2017-07-05 20:35:37', '2017-07-05 19:35:37', '', 64, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=75', 1, 'acf-field', '', 0),
(76, 1, '2017-03-21 00:23:18', '2017-03-20 23:23:18', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_58d064489bdeb', '', '', '2017-03-21 00:26:29', '2017-03-20 23:26:29', '', 75, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=76', 0, 'acf-field', '', 0),
(80, 1, '2017-03-21 00:26:04', '2017-03-20 23:26:04', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:27:"text dans la boite / bouton";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Titre', 'title', 'publish', 'closed', 'closed', '', 'field_58d064d3c471b', '', '', '2017-03-21 00:26:04', '2017-03-20 23:26:04', '', 64, 'http://ovent.busbz.com/?post_type=acf-field&p=80', 0, 'acf-field', '', 0),
(87, 1, '2017-03-21 00:45:34', '2017-03-20 23:45:34', 'Une cuisine inspirée de la botanique, un restaurant végane et végétarien.\r\n\r\nLOV, c’est une vision. C’est le désir et la volonté de retourner à l’essentiel.\r\nNous mettons à l’honneur les produits de la Terre dans chacun de nos plats,\r\ndans chacune de nos créations.\r\n\r\nApprenez-en plus sur notre démarche et sur notre conception de la cuisine.', 'Ô vent', '', 'publish', 'closed', 'open', '', 'o-vent', '', '', '2017-07-05 22:15:11', '2017-07-05 21:15:11', '', 0, 'http://ovent.busbz.com/?page_id=87', 0, 'page', '', 0),
(88, 1, '2017-03-21 00:45:34', '2017-03-20 23:45:34', 'Sous-vêtements éco-responsables pour hommes et femmes\r\n\r\net autres accessoires fabriqués à Montréal\r\n\r\ndans un environement zéro déchet', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-03-21 00:45:34', '2017-03-20 23:45:34', '', 87, 'http://ovent.busbz.com/2017/03/21/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2017-03-21 00:45:58', '2017-03-20 23:45:58', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2017-03-21 00:45:58', '2017-03-20 23:45:58', '', 0, 'http://ovent.busbz.com/?p=89', 1, 'nav_menu_item', '', 0),
(90, 1, '2017-07-05 20:20:13', '2017-07-05 19:20:13', 'Une cuisine inspirée de la botanique, un restaurant végane et végétarien.\n\nLOV, c’est une vision. C’est le désir et la volonté de retourner à l’essentiel.\nNous mettons à l’honneur les produits de la Terre dans chacun de nos plats,\ndans chacune de nos créations.\n\nApprenez-en plus sur notre démarche et sur notre conception de la cuisine.', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-autosave-v1', '', '', '2017-07-05 20:20:13', '2017-07-05 19:20:13', '', 87, 'http://ovent.busbz.com/2017/03/21/87-autosave-v1/', 0, 'revision', '', 0),
(91, 1, '2017-03-21 04:33:07', '2017-03-21 03:33:07', 'Sous-vêtements éco-responsables\r\npour hommes et femmes\r\n\r\net autres accessoires fabriqués à Montréal\r\ndans un environement zéro déchet', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-03-21 04:33:07', '2017-03-21 03:33:07', '', 87, 'http://ovent.busbz.com/2017/03/21/87-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2017-03-21 04:33:39', '2017-03-21 03:33:39', '<h1>Sous-vêtements éco-responsables\r\npour hommes et femmes</h1>\r\n<h2>et autres accessoires fabriqués à Montréal\r\ndans un environement zéro déchet</h2>', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-03-21 04:33:39', '2017-03-21 03:33:39', '', 87, 'http://ovent.busbz.com/2017/03/21/87-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2017-03-21 05:17:51', '2017-03-21 04:17:51', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:13:"ovent_options";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Options', 'options', 'publish', 'closed', 'closed', '', 'group_58d0a886483a8', '', '', '2017-03-21 05:18:46', '2017-03-21 04:18:46', '', 0, 'http://ovent.busbz.com/?post_type=acf-field-group&#038;p=93', 0, 'acf-field-group', '', 0),
(94, 1, '2017-03-21 05:17:51', '2017-03-21 04:17:51', 'a:7:{s:4:"type";s:3:"tab";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"placement";s:4:"left";s:8:"endpoint";i:0;}', 'Footer', 'footer', 'publish', 'closed', 'closed', '', 'field_58d0a89dad07d', '', '', '2017-03-21 05:17:51', '2017-03-21 04:17:51', '', 93, 'http://ovent.busbz.com/?post_type=acf-field&p=94', 0, 'acf-field', '', 0),
(95, 1, '2017-03-21 05:17:51', '2017-03-21 04:17:51', 'a:10:{s:4:"type";s:8:"repeater";s:12:"instructions";s:24:"affichés dans le footer";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"collapsed";s:19:"field_58d0a92bad080";s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"block";s:12:"button_label";s:0:"";}', 'Credits', 'credits', 'publish', 'closed', 'closed', '', 'field_58d0a8bdad07e', '', '', '2017-03-21 05:18:46', '2017-03-21 04:18:46', '', 93, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=95', 1, 'acf-field', '', 0),
(96, 1, '2017-03-21 05:17:51', '2017-03-21 04:17:51', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:25:"(optionel - avec http://)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Lien', 'link', 'publish', 'closed', 'closed', '', 'field_58d0a8e1ad07f', '', '', '2017-03-21 05:17:51', '2017-03-21 04:17:51', '', 95, 'http://ovent.busbz.com/?post_type=acf-field&p=96', 0, 'acf-field', '', 0),
(97, 1, '2017-03-21 05:17:51', '2017-03-21 04:17:51', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Text alternatif', 'label', 'publish', 'closed', 'closed', '', 'field_58d0a952ad081', '', '', '2017-03-21 05:17:51', '2017-03-21 04:17:51', '', 95, 'http://ovent.busbz.com/?post_type=acf-field&p=97', 1, 'acf-field', '', 0),
(98, 1, '2017-03-21 05:17:51', '2017-03-21 04:17:51', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Image', 'image', 'publish', 'closed', 'closed', '', 'field_58d0a92bad080', '', '', '2017-03-21 05:17:51', '2017-03-21 04:17:51', '', 95, 'http://ovent.busbz.com/?post_type=acf-field&p=98', 2, 'acf-field', '', 0),
(99, 1, '2017-03-21 05:19:53', '2017-03-21 04:19:53', '', 'Membre', '', 'inherit', 'open', 'closed', '', 'membre', '', '', '2017-03-21 05:19:57', '2017-03-21 04:19:57', '', 0, 'http://ovent.busbz.com/wp-content/uploads/2017/03/Membre.jpg', 0, 'attachment', 'image/jpeg', 0),
(100, 1, '2017-03-21 05:21:51', '2017-03-21 04:21:51', '', 'dyade-photo', '', 'inherit', 'open', 'closed', '', 'dyade-photo', '', '', '2017-03-21 05:21:53', '2017-03-21 04:21:53', '', 0, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 1, '2017-03-27 18:13:49', '2017-03-27 17:13:49', '<h1>Sous-vêtements éco-responsables\r\npour hommes et femmes</h1>\r\n<h2>et autres accessoires fabriqués à Montréal\r\ndans un environement zéro déchet</h2>', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '56-revision-v1', '', '', '2017-03-27 18:13:49', '2017-03-27 17:13:49', '', 56, 'http://ovent.busbz.com/2017/03/27/56-revision-v1/', 0, 'revision', '', 0),
(107, 1, '2017-05-08 18:28:15', '2017-05-08 17:28:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:22:"Gros titre de la slide";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Titre', 'title', 'publish', 'closed', 'closed', '', 'field_5910a92232889', '', '', '2017-05-08 18:28:15', '2017-05-08 17:28:15', '', 105, 'http://ovent.busbz.com/?post_type=acf-field&p=107', 0, 'acf-field', '', 0),
(108, 1, '2017-05-08 18:28:15', '2017-05-08 17:28:15', 'a:10:{s:4:"type";s:4:"text";s:12:"instructions";s:19:"Plus petit texte...";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:2:"50";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";}', 'Sous titre', 'subtitle', 'publish', 'closed', 'closed', '', 'field_5910a9483288a', '', '', '2017-05-08 18:28:15', '2017-05-08 17:28:15', '', 105, 'http://ovent.busbz.com/?post_type=acf-field&p=108', 1, 'acf-field', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(109, 1, '2017-05-08 18:28:15', '2017-05-08 17:28:15', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:13:"Image de fond";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Fond', 'background', 'publish', 'closed', 'closed', '', 'field_5910a9ca3288c', '', '', '2017-05-08 18:33:42', '2017-05-08 17:33:42', '', 105, 'http://ovent.busbz.com/?post_type=acf-field&#038;p=109', 2, 'acf-field', '', 0),
(111, 1, '2017-05-08 18:29:46', '2017-05-08 17:29:46', '', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-05-08 18:29:46', '2017-05-08 17:29:46', '', 87, 'http://ovent.busbz.com/2017/05/08/87-revision-v1/', 0, 'revision', '', 0),
(112, 1, '2017-05-08 18:33:58', '2017-05-08 17:33:58', '', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-05-08 18:33:58', '2017-05-08 17:33:58', '', 87, 'http://ovent.busbz.com/2017/05/08/87-revision-v1/', 0, 'revision', '', 0),
(115, 1, '2017-05-25 01:29:00', '2017-05-25 00:29:00', 'Jeune artiste voguant au gré du vent et des idées qu’elle capture dans les nuages, elle se passionne pour le potentiel énorme &amp; créatif qui émane des enjeux environnementaux. Le samedi, ou les autres jours de la semaine aussi, il est possible de la surprendre en train de tester les limites de sa machine à coudre ou en pleine exploration culinaire, sans aucun but précis sinon celui de (et je la cite) “voir ce que ça va donner.”\r\n\r\nAvec ces quelques indices, certains pourraient être tentés de penser qu’elle est designer de mode un peu grano sur les bords, mais détrompez-vous parce que le fait est qu’elle est beaucoup plus que ça.\r\n\r\nPour tout vous dire, elle s’appelle Ericka, elle est éco-créatrice et elle laisse porter son imagination par le vent qui souffle, mais les deux pieds sur terre. Elle a une conviction profonde en tête: Elle existe pour créer. Et elle crée pour rendre le monde plus beau. Une idée à la fois.\r\n\r\nHiver 2015. <a href="https://www.youtube.com/watch?annotation_id=pfc%3AUHwSk8bFS4M&amp;feature=s2lp&amp;src_vid=jIj9VJEwYEk&amp;v=UHwSk8bFS4M" target="_blank" rel="noopener noreferrer">Il fait froid dehors mais jusque là, tout est normal.</a> Et tout le serait resté si ce courant d’air ne lui avait pas traversé les deux oreilles: Il fallait faire quelque chose pour apaiser la tension qui règne avec de plus en plus d’intensité. C’est donc dans ce désir de légèreté, sur une planète de toute évidence, de plus en plus chargée, qu’est né Ô VENT.\r\n\r\nCrédits photo: Dyade photo <a title="Dyade photo" href="http://www.dyadephoto.com" target="_blank" rel="noopener noreferrer">[site]</a> <a title="Dyade photo" href="https://www.facebook.com/dyadephoto" target="_blank" rel="noopener noreferrer">[facebook]</a>', 'La créatrice', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2017-05-25 01:29:00', '2017-05-25 00:29:00', '', 8, 'http://ovent.busbz.com/2017/05/25/8-revision-v1/', 0, 'revision', '', 0),
(116, 1, '2017-05-26 17:26:26', '2017-05-26 16:26:26', '', 'bobette o vent eco creation', '', 'inherit', 'open', 'closed', '', 'bobette-o-vent-eco-creation', '', '', '2017-05-26 17:26:26', '2017-05-26 16:26:26', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/bobette-o-vent-eco-creation.jpg', 0, 'attachment', 'image/jpeg', 0),
(117, 1, '2017-05-26 17:28:03', '2017-05-26 16:28:03', '', 'BR_dyade-photo-o-vent-decembre-1039', '', 'inherit', 'open', 'closed', '', 'br_dyade-photo-o-vent-decembre-1039', '', '', '2017-07-05 20:37:25', '2017-07-05 19:37:25', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/BR_dyade-photo-o-vent-decembre-1039.jpg', 0, 'attachment', 'image/jpeg', 0),
(118, 1, '2017-05-26 17:28:20', '2017-05-26 16:28:20', '', 'BR_dyade-photo-o-vent-decembre-1056', '', 'inherit', 'open', 'closed', '', 'br_dyade-photo-o-vent-decembre-1056', '', '', '2017-05-26 17:28:20', '2017-05-26 16:28:20', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/BR_dyade-photo-o-vent-decembre-1056.jpg', 0, 'attachment', 'image/jpeg', 0),
(119, 1, '2017-05-26 17:28:33', '2017-05-26 16:28:33', '', 'BR_dyade-photo-o-vent-decembre-1067', '', 'inherit', 'open', 'closed', '', 'br_dyade-photo-o-vent-decembre-1067', '', '', '2017-05-26 17:28:33', '2017-05-26 16:28:33', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/BR_dyade-photo-o-vent-decembre-1067.jpg', 0, 'attachment', 'image/jpeg', 0),
(120, 1, '2017-05-26 17:28:49', '2017-05-26 16:28:49', '', 'BR_dyade-photo-o-vent-decembre-1079', '', 'inherit', 'open', 'closed', '', 'br_dyade-photo-o-vent-decembre-1079', '', '', '2017-05-26 17:28:49', '2017-05-26 16:28:49', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/BR_dyade-photo-o-vent-decembre-1079.jpg', 0, 'attachment', 'image/jpeg', 0),
(121, 1, '2017-05-26 17:29:03', '2017-05-26 16:29:03', '', 'BR_dyade-photo-o-vent-decembre-1083', '', 'inherit', 'open', 'closed', '', 'br_dyade-photo-o-vent-decembre-1083', '', '', '2017-05-26 17:29:03', '2017-05-26 16:29:03', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/BR_dyade-photo-o-vent-decembre-1083.jpg', 0, 'attachment', 'image/jpeg', 0),
(123, 1, '2017-05-26 17:30:11', '2017-05-26 16:30:11', '', 'dyade-photo-ovent-2016-06-24', '', 'inherit', 'open', 'closed', '', 'dyade-photo-ovent-2016-06-24', '', '', '2017-05-26 17:30:11', '2017-05-26 16:30:11', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo-ovent-2016-06-24.jpg', 0, 'attachment', 'image/jpeg', 0),
(124, 1, '2017-05-26 17:30:26', '2017-05-26 16:30:26', '', 'dyade-photo-ovent-2016-06-142', '', 'inherit', 'open', 'closed', '', 'dyade-photo-ovent-2016-06-142', '', '', '2017-05-26 17:30:26', '2017-05-26 16:30:26', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo-ovent-2016-06-142.jpg', 0, 'attachment', 'image/jpeg', 0),
(125, 1, '2017-05-26 17:30:42', '2017-05-26 16:30:42', '', 'dyade-photo-ovent-2016-06-796', '', 'inherit', 'open', 'closed', '', 'dyade-photo-ovent-2016-06-796', '', '', '2017-05-26 17:30:42', '2017-05-26 16:30:42', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo-ovent-2016-06-796.jpg', 0, 'attachment', 'image/jpeg', 0),
(126, 1, '2017-05-26 17:30:58', '2017-05-26 16:30:58', '', 'dyade-photo-ovent-2016-06-962', '', 'inherit', 'open', 'closed', '', 'dyade-photo-ovent-2016-06-962', '', '', '2017-05-26 17:30:58', '2017-05-26 16:30:58', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo-ovent-2016-06-962.jpg', 0, 'attachment', 'image/jpeg', 0),
(127, 1, '2017-05-26 17:31:09', '2017-05-26 16:31:09', '', 'dyade-photo-ovent-2016-06-1086', '', 'inherit', 'open', 'closed', '', 'dyade-photo-ovent-2016-06-1086', '', '', '2017-05-26 17:31:09', '2017-05-26 16:31:09', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo-ovent-2016-06-1086.jpg', 0, 'attachment', 'image/jpeg', 0),
(128, 1, '2017-05-26 17:31:30', '2017-05-26 16:31:30', '', 'dyade-photo-ovent-2016-06-335', '', 'inherit', 'open', 'closed', '', 'dyade-photo-ovent-2016-06-335', '', '', '2017-05-26 17:31:30', '2017-05-26 16:31:30', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/dyade-photo-ovent-2016-06-335.jpg', 0, 'attachment', 'image/jpeg', 0),
(129, 1, '2017-05-26 17:41:10', '2017-05-26 16:41:10', '', 'o vent sacs vrac-1', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-1', '', '', '2017-07-05 20:37:40', '2017-07-05 19:37:40', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(130, 1, '2017-05-26 17:41:46', '2017-05-26 16:41:46', '', 'o vent sacs vrac-2', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-2', '', '', '2017-05-26 17:41:46', '2017-05-26 16:41:46', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(131, 1, '2017-05-26 17:42:23', '2017-05-26 16:42:23', '', 'o vent sacs vrac-3', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-3', '', '', '2017-05-26 17:42:23', '2017-05-26 16:42:23', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(132, 1, '2017-05-26 17:43:06', '2017-05-26 16:43:06', '', 'o vent sacs vrac-4', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-4', '', '', '2017-05-26 17:43:06', '2017-05-26 16:43:06', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(133, 1, '2017-05-26 17:43:55', '2017-05-26 16:43:55', '', 'o vent sacs vrac-5', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-5', '', '', '2017-05-26 17:43:55', '2017-05-26 16:43:55', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(134, 1, '2017-05-26 17:44:24', '2017-05-26 16:44:24', '', 'o vent sacs vrac-6', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-6', '', '', '2017-05-26 17:44:24', '2017-05-26 16:44:24', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(135, 1, '2017-05-26 17:44:55', '2017-05-26 16:44:55', '', 'o vent sacs vrac-7', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-7', '', '', '2017-05-26 17:44:55', '2017-05-26 16:44:55', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-7.jpg', 0, 'attachment', 'image/jpeg', 0),
(136, 1, '2017-05-26 17:45:24', '2017-05-26 16:45:24', '', 'o vent sacs vrac-8', '', 'inherit', 'open', 'closed', '', 'o-vent-sacs-vrac-8', '', '', '2017-05-26 17:45:24', '2017-05-26 16:45:24', '', 56, 'http://ovent.busbz.com/wp-content/uploads/2017/03/o-vent-sacs-vrac-8.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(138, 1, '2017-07-05 20:20:38', '2017-07-05 19:20:38', 'Une cuisine inspirée de la botanique, un restaurant végane et végétarien.\r\n\r\nLOV, c’est une vision. C’est le désir et la volonté de retourner à l’essentiel.\r\nNous mettons à l’honneur les produits de la Terre dans chacun de nos plats,\r\ndans chacune de nos créations.\r\n\r\nApprenez-en plus sur notre démarche et sur notre conception de la cuisine.', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-07-05 20:20:38', '2017-07-05 19:20:38', '', 87, 'http://ovent.busbz.com/2017/07/05/87-revision-v1/', 0, 'revision', '', 0),
(139, 1, '2017-07-05 20:36:11', '2017-07-05 19:36:11', 'Une cuisine inspirée de la botanique, un restaurant végane et végétarien.\r\n\r\nLOV, c’est une vision. C’est le désir et la volonté de retourner à l’essentiel.\r\nNous mettons à l’honneur les produits de la Terre dans chacun de nos plats,\r\ndans chacune de nos créations.\r\n\r\nApprenez-en plus sur notre démarche et sur notre conception de la cuisine.', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-07-05 20:36:11', '2017-07-05 19:36:11', '', 87, 'http://ovent.busbz.com/2017/07/05/87-revision-v1/', 0, 'revision', '', 0),
(140, 1, '2017-07-05 20:37:45', '2017-07-05 19:37:45', 'Une cuisine inspirée de la botanique, un restaurant végane et végétarien.\r\n\r\nLOV, c’est une vision. C’est le désir et la volonté de retourner à l’essentiel.\r\nNous mettons à l’honneur les produits de la Terre dans chacun de nos plats,\r\ndans chacune de nos créations.\r\n\r\nApprenez-en plus sur notre démarche et sur notre conception de la cuisine.', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-07-05 20:37:45', '2017-07-05 19:37:45', '', 87, 'http://ovent.busbz.com/2017/07/05/87-revision-v1/', 0, 'revision', '', 0),
(141, 1, '2017-07-05 20:38:26', '2017-07-05 19:38:26', 'Une cuisine inspirée de la botanique, un restaurant végane et végétarien.\r\n\r\nLOV, c’est une vision. C’est le désir et la volonté de retourner à l’essentiel.\r\nNous mettons à l’honneur les produits de la Terre dans chacun de nos plats,\r\ndans chacune de nos créations.\r\n\r\nApprenez-en plus sur notre démarche et sur notre conception de la cuisine.', 'Ô vent', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2017-07-05 20:38:26', '2017-07-05 19:38:26', '', 87, 'http://ovent.busbz.com/2017/07/05/87-revision-v1/', 0, 'revision', '', 0),
(142, 1, '2017-07-05 22:14:34', '2017-07-05 21:14:34', '', 'ovent_2015-04-01-2301', '', 'inherit', 'open', 'closed', '', 'ovent_2015-04-01-2301', '', '', '2017-07-05 22:14:34', '2017-07-05 21:14:34', '', 0, 'http://ovent.busbz.com/wp-content/uploads/2017/07/ovent_2015-04-01-2301.jpg', 0, 'attachment', 'image/jpeg', 0),
(143, 1, '2017-07-05 22:14:37', '2017-07-05 21:14:37', '', 'ovent_2015-04-01-1634', '', 'inherit', 'open', 'closed', '', 'ovent_2015-04-01-1634', '', '', '2017-07-05 22:14:37', '2017-07-05 21:14:37', '', 0, 'http://ovent.busbz.com/wp-content/uploads/2017/07/ovent_2015-04-01-1634.jpg', 0, 'attachment', 'image/jpeg', 0),
(144, 1, '2017-10-14 18:51:30', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2017-10-14 18:51:30', '0000-00-00 00:00:00', '', 0, 'http://ovent.busbz.com/?p=144', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 3, 0),
(1, 4, 0),
(8, 2, 0),
(8, 4, 0),
(8, 7, 0),
(8, 10, 0),
(10, 6, 0),
(10, 10, 0),
(15, 5, 0),
(16, 5, 0),
(18, 2, 0),
(18, 11, 0),
(19, 6, 0),
(19, 11, 0),
(22, 5, 0),
(23, 5, 0),
(24, 12, 0),
(25, 12, 0),
(27, 12, 0),
(48, 2, 0),
(52, 12, 0),
(56, 6, 0),
(56, 14, 0),
(60, 12, 0),
(87, 2, 0),
(87, 14, 0),
(89, 5, 0),
(144, 2, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'language', 'a:3:{s:6:"locale";s:5:"fr_CA";s:3:"rtl";i:0;s:9:"flag_code";s:6:"quebec";}', 0, 3),
(3, 3, 'term_language', '', 0, 1),
(4, 4, 'term_translations', 'a:2:{s:2:"fr";i:1;s:2:"en";i:8;}', 0, 2),
(5, 5, 'nav_menu', '', 0, 5),
(6, 6, 'language', 'a:3:{s:6:"locale";s:5:"en_CA";s:3:"rtl";i:0;s:9:"flag_code";s:2:"ca";}', 0, 3),
(7, 7, 'term_language', '', 0, 1),
(8, 8, 'category', '', 0, 0),
(10, 10, 'post_translations', 'a:2:{s:2:"fr";i:8;s:2:"en";i:10;}', 0, 2),
(11, 11, 'post_translations', 'a:2:{s:2:"en";i:19;s:2:"fr";i:18;}', 0, 2),
(12, 12, 'nav_menu', '', 0, 5),
(13, 13, 'shop', '', 0, 0),
(14, 14, 'post_translations', 'a:2:{s:2:"fr";i:87;s:2:"en";i:56;}', 0, 2) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 13, 'address', '290, rue de la Montagne'),
(2, 13, '_address', 'field_58cd962fa0b1b'),
(3, 13, 'address_bis', 'Montréal'),
(4, 13, '_address_bis', 'field_58cd966fa0b1c'),
(5, 13, 'map', 'a:3:{s:7:"address";s:44:"290 Rue de la Montagne, Montreal, QC, Canada";s:3:"lat";s:17:"45.49196999999999";s:3:"lng";s:10:"-73.561802";}'),
(6, 13, '_map', 'field_58cd96e4a0b20'),
(7, 13, 'web', 'http://www.le5ieme.com'),
(8, 13, '_web', 'field_58cd9685a0b1d'),
(9, 13, 'email', ''),
(10, 13, '_email', 'field_58cd96b3a0b1e'),
(11, 13, 'phone', ''),
(12, 13, '_phone', 'field_58cd96c6a0b1f') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Non classé', 'non-classe', 0),
(2, 'Français', 'fr', 0),
(3, 'Français', 'pll_fr', 0),
(4, 'pll_58bb553c10bed', 'pll_58bb553c10bed', 0),
(5, 'Menu principal', 'menu-principal', 0),
(6, 'English', 'en', 1),
(7, 'English', 'pll_en', 0),
(8, 'Non classé', 'non-classe-en', 0),
(10, 'pll_58c5837624543', 'pll_58c5837624543', 0),
(11, 'pll_58c74cb6b5e96', 'pll_58c74cb6b5e96', 0),
(12, 'Main menu', 'main-menu', 0),
(13, 'Le 5e (Café zéro déchet)', 'le-5e-cafe-zero-dechet', 0),
(14, 'pll_58d05e25ad71d', 'pll_58d05e25ad71d', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'locale', ''),
(11, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(12, 1, 'wp_user_level', '10'),
(13, 1, 'dismissed_wp_pointers', 'pll_lgt'),
(14, 1, 'show_welcome_panel', '1'),
(16, 1, 'wp_dashboard_quick_press_last_post_id', '144'),
(17, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:15:"title-attribute";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(19, 1, 'nav_menu_recently_edited', '5'),
(20, 1, 'wp_user-settings', 'editor=tinymce&libraryContent=browse'),
(21, 1, 'wp_user-settings-time', '1499289289'),
(22, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(23, 1, 'manageedit-shopcolumnshidden', 'a:0:{}'),
(26, 1, 'acf_user_settings', 'a:2:{s:29:"collapsed_field_58d0a8bdad07e";s:3:"0,1";s:29:"collapsed_field_5910a9633288b";s:1:"0";}'),
(27, 1, 'closedpostboxes_page', 'a:0:{}'),
(28, 1, 'metaboxhidden_page', 'a:9:{i:0;s:23:"acf-group_58cd961f82922";i:1;s:23:"acf-group_58d0a886483a8";i:2;s:23:"acf-group_58cda39574b81";i:3;s:12:"revisionsdiv";i:4;s:10:"postcustom";i:5;s:16:"commentstatusdiv";i:6;s:11:"commentsdiv";i:7;s:7:"slugdiv";i:8;s:9:"authordiv";}'),
(29, 1, 'session_tokens', 'a:1:{s:64:"545b9b0e0459026dd1d1a6d10d8a4c20c6499c69ae8bb67c9ddc63180e775dd4";a:4:{s:10:"expiration";i:1508176288;s:2:"ip";s:3:"::1";s:2:"ua";s:115:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";s:5:"login";i:1508003488;}}'),
(30, 1, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:23:"acf-group_58cd961f82922";s:4:"side";s:43:"ml_box,submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:142:"acf-group_58d0a886483a8,acf-group_58cda39574b81,revisionsdiv,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv,acf-group_58d05f045da36";s:8:"advanced";s:0:"";}'),
(31, 1, 'screen_layout_page', '2'),
(32, 1, 'wp_media_library_mode', 'list'),
(33, 1, 'community-events-location', 'a:1:{s:2:"ip";s:2:"::";}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BGTaj0bevPlNcIs4Cy6YyXcmovwikU0', 'admin', 'hello@nusson.ninja', '', '2017-03-04 23:17:02', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

